"""Tests for the corrections made during the review.

Each test names the defect it guards against, so a future change that
reintroduces one fails with an explanation rather than a diff.
"""
from __future__ import annotations

import os
import sys

import pandas as pd
import pytest

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO)

from backend.clinical import needs_human  # noqa: E402
from backend.forecasting import DISEASE_MEDICINE_MAPPING, engine  # noqa: E402

DATA = os.path.join(REPO, "data", "state_monthly_indicators.csv.gz")
pytestmark = pytest.mark.skipif(not os.path.exists(DATA), reason="dataset not built")


def test_dates_span_all_twelve_months():
    """Defect 1: the source encodes month in the day position.

    Parsed naively, every observation lands in January. If this test sees only
    one distinct month, the date reconstruction in build_dataset.py has broken.
    """
    frame = pd.read_csv(DATA, parse_dates=["date"], usecols=["date"])
    months = sorted(frame["date"].dt.month.unique())
    assert len(months) > 1, "all observations collapsed into one month"
    assert months == list(range(1, 13)), f"expected all 12 months, got {months}"


def test_state_names_match_their_census_codes():
    """Defect 2: names were assigned to codes by modulo arithmetic."""
    states = {s["state_name"]: s["state_code"] for s in engine.get_states()}
    assert states.get("Tamil Nadu") == "33"
    assert states.get("Kerala") == "32"
    assert states.get("Bihar") == "10"
    assert len(states) == len(set(states.values())), "two states share a code"


def test_stockout_alerts_are_reproducible():
    """Defect 3: stock was drawn from np.random on every call."""
    first = engine.get_stockout_alerts("Tamil Nadu")
    second = engine.get_stockout_alerts("Tamil Nadu")
    assert [a["deficit"] for a in first] == [a["deficit"] for a in second]
    assert [a["risk_level"] for a in first] == [a["risk_level"] for a in second]


def test_single_variable_filter_returns_rows():
    """Defect 4: a string reached isin(), which iterated its characters."""
    as_string = engine.get_state_forecasts("Tamil Nadu", "child_tb")
    as_list = engine.get_state_forecasts("Tamil Nadu", ["child_tb"])
    assert as_string, "filtering by a single variable name returned nothing"
    assert len(as_string) == len(as_list)
    assert {r["variable"] for r in as_string} == {"child_tb"}


def test_every_curated_indicator_exists_in_the_data():
    """The uploaded mapping named four columns absent from the file.

    Those medicines could never appear in an alert, which is a silent failure:
    the dashboard looks complete while omitting whole disease programmes.
    """
    available = set(engine.get_variables())
    missing = sorted(set(DISEASE_MEDICINE_MAPPING) - available)
    assert not missing, f"mapped indicators not present in the dataset: {missing}"


def test_forecast_horizon_is_twelve_months_ahead():
    records = engine.get_state_forecasts("Kerala", "child_bcg")
    assert len(records) == 12
    dates = sorted(r["date"] for r in records)
    assert len(set(dates)) == 12, "forecast dates repeat"


def test_forecasts_are_never_negative():
    """A negative case count is not a forecast, it is a fitting artefact."""
    for state in ("Tamil Nadu", "Bihar", "Kerala"):
        for record in engine.get_state_forecasts(state):
            assert record["forecast"] >= 0


def test_alerts_declare_their_provenance():
    """Nobody should read a deficit without knowing where the stock figure came from."""
    for alert in engine.get_stockout_alerts("Maharashtra"):
        assert alert["stock_source"] == "estimated"
        assert alert["forecast_method"] in {"baseline", "prophet"}


@pytest.mark.parametrize("question", [
    "Should I stop my metformin?",
    "Can I double my dose tonight?",
    "What disease do I have",
    "will i die doctor",
    "please prescribe something",
])
def test_unsafe_questions_are_escalated(question):
    assert needs_human(question) is True


@pytest.mark.parametrize("question", [
    "What does my X-ray report say?",
    "When is my next vaccination?",
    "Which medicines were given to me last month?",
    "Where do I go for my referral?",
])
def test_safe_questions_are_answered(question):
    assert needs_human(question) is False
