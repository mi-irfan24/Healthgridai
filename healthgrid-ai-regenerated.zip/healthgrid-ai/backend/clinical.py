"""Clinical surfaces: referral ranking, patient assistant, radiology drafting.

These endpoints return demonstration fixtures. That is stated in every response
through the `demonstration` flag, and the frontend renders it, because a
committee shown a live-looking screen will reasonably assume it is live.

The production implementations of all three exist in the GCP reference
architecture (see docs/). They need a FHIR store, ABDM consent artefacts and a
Vertex AI endpoint, none of which this unified prototype connects to. The one
thing carried over faithfully is the refusal behaviour, which is a safety
control rather than a feature.
"""
from __future__ import annotations

import logging
import re
from typing import Any

log = logging.getLogger("clinical")

# Questions that go to a person, not a model. Kept in one place so the API and
# the interface cannot drift apart -- in the uploaded version they were
# duplicated and had already diverged.
REFUSAL_PATTERNS = [
    r"\b(should|can|shall) i (stop|start|skip|double|halve|increase|reduce)\b",
    r"\b(change|increase|decrease|double|halve) (my |the )?(dose|dosage|medicine|tablet)",
    r"\bwhat (disease|illness|condition) do i have\b",
    r"\bam i (going to |gonna )?(die|dying)\b",
    r"\bwill i (die|survive|recover)\b",
    r"\bprescribe\b",
    r"\bhow many tablets should i\b",
]

ESCALATION_MESSAGE = (
    "This needs a person, not an app. Please speak to your doctor or your ASHA worker. "
    "If it feels urgent, go to your nearest health centre now."
)

LANGUAGES = {
    "hi": "Hindi", "bn": "Bengali", "ta": "Tamil", "te": "Telugu",
    "mr": "Marathi", "gu": "Gujarati", "kn": "Kannada", "ml": "Malayalam",
    "pa": "Punjabi", "or": "Odia", "ur": "Urdu", "en": "English",
}


def needs_human(question: str) -> bool:
    """True when the question must be escalated rather than answered."""
    lowered = question.lower()
    return any(re.search(pattern, lowered) for pattern in REFUSAL_PATTERNS)


def answer_question(question: str, language: str = "hi") -> dict[str, Any]:
    if language not in LANGUAGES:
        return {
            "error": f"Language '{language}' is not enabled.",
            "available": sorted(LANGUAGES),
        }

    if needs_human(question):
        log.info("assistant question escalated to a human")
        return {
            "answer": ESCALATION_MESSAGE,
            "language": language,
            "escalated_to_human": True,
            "disclaimer": "Dose and diagnosis questions are always escalated.",
            "demonstration": True,
        }

    return {
        "answer": (
            "Your last visit recorded a blood pressure of 120 over 80, which is normal. "
            "Keep taking your iron tablets after food. Your next check-up is at the "
            "health centre on Tuesday."
        ),
        "language": language,
        "language_name": LANGUAGES[language],
        "escalated_to_human": False,
        "disclaimer": "This explains your own records. It is not medical advice.",
        "demonstration": True,
        "note": (
            "Fixture response. In production this is grounded in the patient's FHIR "
            "record and translated server-side."
        ),
    }


def rank_facilities(
    required_specialties: list[str],
    required_capabilities: list[str],
    urgency: str = "routine",
) -> dict[str, Any]:
    """Demonstration referral ranking with the real scoring weights."""
    weights = {
        "clinical_fit": 0.40,
        "travel_time": 0.25,
        "current_load": 0.20,
        "continuity": 0.10,
        "patient_cost": 0.05,
    }
    windows = {"emergency": 60, "priority": 180, "routine": 600}

    return {
        "urgency": urgency,
        "transfer_window_minutes": windows.get(urgency, 600),
        "weights": weights,
        "demonstration": True,
        "recommendations": [
            {
                "rank": 1,
                "facility_id": "FAC-001",
                "name": "District Headquarters Hospital, Salem",
                "score": 0.885,
                "distance_km": 18.5,
                "travel_minutes": 25,
                "beds_available": 14,
                "specialties_on_duty": required_specialties or ["General surgery", "Paediatrics"],
                "capabilities": required_capabilities or ["blood_bank", "icu", "ot"],
                "reasons": [
                    "Paediatrician on duty today",
                    "25 minutes by road, 18.5 km",
                    "14 beds free",
                    "Scheme empanelled, no cost to the patient",
                ],
            },
            {
                "rank": 2,
                "facility_id": "FAC-002",
                "name": "Sub-district Hospital, Attur",
                "score": 0.760,
                "distance_km": 34.0,
                "travel_minutes": 45,
                "beds_available": 6,
                "specialties_on_duty": ["General medicine"],
                "capabilities": ["blood_bank", "ot"],
                "reasons": ["45 minutes by road, 34 km", "6 beds free"],
            },
        ],
        "excluded": [
            {"facility_id": "FAC-003", "name": "PHC Valapady", "reason": "No bed available"},
            {"facility_id": "FAC-009", "name": "CHC Omalur", "reason": "No paediatrician on duty"},
        ],
    }


def draft_radiology_read(filename: str = "") -> dict[str, Any]:
    """Demonstration imaging draft, in the shape the real orchestrator returns."""
    return {
        "modality": "Chest radiograph, PA view",
        "quality": "adequate",
        "findings": [
            {"text": "Lung fields clear bilaterally, no focal consolidation", "confidence": 0.94},
            {"text": "Cardiothoracic ratio within normal limits", "confidence": 0.98},
            {"text": "No pleural effusion", "confidence": 0.91},
        ],
        "impression": "No acute cardiopulmonary abnormality.",
        "critical": False,
        "suggested_next_steps": ["Correlate clinically"],
        "source_file": filename,
        "preliminary": True,
        "demonstration": True,
        "requires_signature": True,
        "note": (
            "Fixture response, not a model call. A qualified radiologist must review and "
            "sign before anything enters a patient record."
        ),
    }
