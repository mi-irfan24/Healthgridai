"""State procurement planning.

Turns the stockout alerts into a prioritised plan. Two paths:

  * CrewAI with Vertex AI Gemini, when the packages and credentials are present.
  * A deterministic heuristic planner otherwise.

Both return the same shape, and the response always says which produced it. The
uploaded version described "5 Vertex AI Gemini agents" in the interface while
defining three in code; the agent roster is now read from the code rather than
asserted in copy.
"""
from __future__ import annotations

import json
import logging
import os
from typing import Any

from .forecasting import SAFETY_STOCK_FRACTION, engine

log = logging.getLogger("procurement")

AGENT_ROSTER = [
    ("Forecast interpretation analyst", "Reads the burden projection and names the indicators driving it."),
    ("Medical planning advisor", "Maps burden to essential medicines and per-case quantities."),
    ("Procurement specialist", "Sequences orders into immediate, scheduled and watch tiers."),
]


def plan_for_state(state: str, top_n: int = 12) -> dict[str, Any]:
    """Build a procurement plan for one state."""
    alerts = engine.get_stockout_alerts(state)
    if not alerts:
        return {
            "status": "no_action",
            "state": state,
            "generated_by": "none",
            "message": (
                f"No shortfall projected for {state} across the curated indicators. "
                "Either stock covers projected demand or the state has no data in this extract."
            ),
            "alerts": [],
        }

    shortlist = alerts[:top_n]
    llm_plan = _run_crew(state, shortlist)
    if llm_plan:
        return {
            "status": "success",
            "state": state,
            "generated_by": "crewai-vertex",
            "agents": [name for name, _ in AGENT_ROSTER],
            "plan_markdown": llm_plan,
            "alerts": shortlist,
            "forecast_method": engine.method,
        }

    return {
        "status": "success",
        "state": state,
        "generated_by": "heuristic",
        "plan_markdown": _heuristic_plan(state, shortlist),
        "alerts": shortlist,
        "forecast_method": engine.method,
    }


def _run_crew(state: str, alerts: list[dict[str, Any]]) -> str | None:
    """Attempt the multi-agent path. Returns None when unavailable."""
    try:
        from crewai import Agent, Crew, Process, Task
        from langchain_google_vertexai import VertexAI
    except ImportError:
        log.info("CrewAI or Vertex AI packages not installed; using the heuristic planner")
        return None

    try:
        llm = VertexAI(
            model_name=os.environ.get("GEMINI_MODEL", "gemini-2.0-flash"),
            temperature=0.2,
            max_output_tokens=2048,
        )

        agents = [
            Agent(role=role, goal=goal,
                  backstory=f"Public health professional working in India's district health system. {goal}",
                  llm=llm, verbose=False)
            for role, goal in AGENT_ROSTER
        ]

        brief = json.dumps(alerts, default=str)
        tasks = [
            Task(
                description=(
                    f"These are the projected shortfalls for {state}, with forecast method "
                    f"'{engine.method}': {brief}. Identify which represent the largest clinical "
                    "risk, and say plainly where the projection is weak."
                ),
                expected_output="A short assessment of burden and where the numbers are uncertain.",
                agent=agents[0],
            ),
            Task(
                description=(
                    f"For {state}, confirm the medicine and per-case quantity for each shortfall "
                    "against Indian standard treatment guidelines. Flag any dosage that looks wrong."
                ),
                expected_output="Medicine-wise requirement with any dosage concerns noted.",
                agent=agents[1],
            ),
            Task(
                description=(
                    f"Produce a procurement plan for {state} in three tiers: order now, order this "
                    f"quarter, and monitor. Assume a {int(SAFETY_STOCK_FRACTION * 100)}% safety "
                    "buffer is already included in the required quantities. Be specific about "
                    "quantities and name what must be verified before an order is raised."
                ),
                expected_output="A tiered procurement plan in markdown.",
                agent=agents[2],
            ),
        ]

        crew = Crew(agents=agents, tasks=tasks, process=Process.sequential, verbose=False)
        return str(crew.kickoff())

    except Exception as exc:
        # A planning request must not fail because a model endpoint is down.
        log.warning("CrewAI run failed, falling back to the heuristic planner: %s", exc)
        return None


def _heuristic_plan(state: str, alerts: list[dict[str, Any]]) -> str:
    """Deterministic plan. Same tiers, no model."""
    tiers: dict[str, list[dict[str, Any]]] = {"CRITICAL": [], "HIGH": [], "MODERATE": []}
    for alert in alerts:
        tiers[alert["risk_level"]].append(alert)

    lines = [
        f"## Procurement plan for {state}",
        "",
        f"Built from a {engine.method} forecast over the next 12 months. Required "
        f"quantities already include a {int(SAFETY_STOCK_FRACTION * 100)}% safety buffer. "
        "Stock positions are estimates until the state drug logistics feed is connected, "
        "so verify each line against the warehouse before raising an order.",
        "",
    ]

    headings = [
        ("CRITICAL", "Order now", "Under 60% of projected need on hand."),
        ("HIGH", "Order this quarter", "Between 60% and 80% of projected need."),
        ("MODERATE", "Monitor", "Above 80% covered; review next cycle."),
    ]

    for level, heading, note in headings:
        items = tiers[level]
        if not items:
            continue
        lines += [f"### {heading}", f"_{note}_", ""]
        for item in items:
            lines.append(
                f"- **{item['medicine']}** for {item['disease'].lower()}: "
                f"order about {item['deficit']:,} {item['unit']} "
                f"(need {item['required_quantity']:,}, estimated {item['estimated_stock']:,} on hand, "
                f"from {item['forecast_cases']:,.0f} projected cases)"
            )
        lines.append("")

    lines += [
        "### Before raising the order",
        "",
        "- Confirm stock on hand against the district warehouse, not this estimate.",
        "- Check the per-case dosage against the current standard treatment guideline.",
        "- Account for lead time; a 12-month projection does not describe next week.",
    ]
    return "\n".join(lines)
