"""Disease burden forecasting and medicine demand estimation.

Reads the compact state-month indicator file, projects each (state, indicator)
series forward twelve months, converts predicted cases into medicine quantities
using per-case dosages, and flags where predicted demand outruns stock.

Two things about the forecast are stated plainly rather than buried, because a
procurement decision worth crores should not rest on a number whose provenance
is unclear:

  * If `data/prophet_forecasts.csv.gz` exists (written by scripts/train_prophet.py)
    those values are used and `method` reports "prophet".
  * Otherwise a trend-plus-seasonal baseline is computed in-process and `method`
    reports "baseline". The baseline is honest and reproducible, not a stand-in
    pretending to be a trained model.

Stock figures are estimates until a DVDMS or e-Aushadhi feed is connected. They
are deterministic per item so the same query always returns the same deficit.
"""
from __future__ import annotations

import hashlib
import logging
import os
from typing import Any, Optional

import numpy as np
import pandas as pd

log = logging.getLogger("forecasting")

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(REPO, "data")
INDICATORS_PATH = os.path.join(DATA_DIR, "state_monthly_indicators.csv.gz")
PROPHET_PATH = os.path.join(DATA_DIR, "prophet_forecasts.csv.gz")

FORECAST_MONTHS = 12
SAFETY_STOCK_FRACTION = 0.30

# Per-case medicine requirements, aligned to Indian standard treatment
# guidelines. This mapping is what turns a case count into a procurement
# quantity, and it is the most load-bearing table in the service.
DISEASE_MEDICINE_MAPPING: dict[str, dict[str, Any]] = {
    # Every key below is a column that exists in the dataset. The uploaded
    # version mapped four indicators that are not in the file at all
    # (malaria_pv, diarrhea_cases, pneumonia_child, anemia_pregnant), so those
    # medicines never appeared in a single alert. Corrected against the real
    # 286-column schema.
    "child_malaria":                       {"disease": "Malaria in children",              "medicine": "Artemether with lumefantrine",            "dose_per_case": 6,   "unit": "tablets"},
    "inpatient_malaria":                   {"disease": "Malaria, admitted",                "medicine": "Artesunate injection",                    "dose_per_case": 9,   "unit": "vials"},
    "dengue_elisa_pos":                    {"disease": "Dengue, ELISA confirmed",          "medicine": "Paracetamol and intravenous fluids",      "dose_per_case": 20,  "unit": "tablets or units"},
    "inpatient_dengue":                    {"disease": "Dengue, admitted",                 "medicine": "Intravenous fluids and platelet support", "dose_per_case": 30,  "unit": "units"},
    "child_tb":                            {"disease": "Tuberculosis in children",         "medicine": "Four-drug fixed-dose combination",        "dose_per_case": 60,  "unit": "tablets"},
    "child_diarr":                         {"disease": "Childhood diarrhoea",              "medicine": "Oral rehydration salts with zinc",        "dose_per_case": 10,  "unit": "sachets"},
    "inpatient_diarrhea_with_dehydration": {"disease": "Diarrhoea with dehydration",       "medicine": "Ringer lactate and oral rehydration salts","dose_per_case": 14,  "unit": "units"},
    "child_pneumonia":                     {"disease": "Childhood pneumonia",              "medicine": "Amoxicillin dispersible tablets",         "dose_per_case": 20,  "unit": "tablets"},
    "pw_ifa180":                           {"disease": "Pregnancy, iron supplementation",  "medicine": "Iron and folic acid tablets",             "dose_per_case": 180, "unit": "tablets"},
    "pw_severe_anemia_tx":                 {"disease": "Severe anaemia in pregnancy",      "medicine": "Iron sucrose injection",                  "dose_per_case": 5,   "unit": "vials"},
    "mother_ifa180_pp":                    {"disease": "Postpartum iron supplementation",  "medicine": "Iron and folic acid tablets",             "dose_per_case": 180, "unit": "tablets"},
    "child_6_59m_ifa_8_10d":               {"disease": "Child iron supplementation",       "medicine": "Iron and folic acid syrup",               "dose_per_case": 10,  "unit": "bottles"},
    "child_bcg":                           {"disease": "BCG immunisation",                 "medicine": "BCG vaccine",                             "dose_per_case": 1,   "unit": "doses"},
    "child_measles":                       {"disease": "Measles immunisation",             "medicine": "Measles and rubella vaccine",             "dose_per_case": 1,   "unit": "doses"},
}


def _fallback(variable: str) -> dict[str, Any]:
    """Indicators outside the curated mapping still need a quantity."""
    label = variable.replace("_", " ").strip().title()
    return {
        "disease": label,
        "medicine": f"Essential supplies for {label.lower()}",
        "dose_per_case": 10,
        "unit": "units",
        "curated": False,
    }


def _stock_ratio(state: str, variable: str) -> float:
    """Deterministic stock-on-hand ratio between 0.40 and 0.95.

    Derived from a hash of the state and indicator so the same item always
    yields the same figure. The previous implementation drew a fresh random
    number per request, which meant the deficit changed on every page refresh --
    a number nobody can act on. Replace this whole function with the DVDMS
    stock-on-hand call when that integration lands.
    """
    digest = hashlib.sha256(f"{state}|{variable}".encode("utf-8")).digest()
    fraction = int.from_bytes(digest[:4], "big") / 0xFFFFFFFF
    return 0.40 + fraction * 0.55


class ForecastingEngine:
    """Loads the indicator history and answers forecast and stockout queries."""

    def __init__(self, indicators_path: str = INDICATORS_PATH, prophet_path: str = PROPHET_PATH):
        self.indicators_path = indicators_path
        self.prophet_path = prophet_path
        self.method = "unavailable"
        self._history: pd.DataFrame = pd.DataFrame()
        self._forecast: pd.DataFrame = pd.DataFrame()
        self._load()

    # -------------------------------------------------------------- loading
    def _load(self) -> None:
        if not os.path.exists(self.indicators_path):
            log.error(
                "Indicator file missing at %s. Run scripts/build_dataset.py "
                "against the raw CSV to create it.", self.indicators_path,
            )
            return

        self._history = pd.read_csv(self.indicators_path, parse_dates=["date"])
        log.info(
            "Loaded %s observations: %d states, %d indicators, %s to %s",
            f"{len(self._history):,}",
            self._history["state_name"].nunique(),
            self._history["variable"].nunique(),
            self._history["date"].min().date(),
            self._history["date"].max().date(),
        )

        if os.path.exists(self.prophet_path):
            self._forecast = pd.read_csv(self.prophet_path, parse_dates=["date"])
            self.method = "prophet"
            log.info("Using trained Prophet forecasts from %s", self.prophet_path)
        else:
            self._forecast = self._baseline_forecast()
            self.method = "baseline"
            log.warning(
                "No trained forecasts found. Using the in-process baseline. "
                "Run scripts/train_prophet.py for Prophet forecasts."
            )

    def _baseline_forecast(self) -> pd.DataFrame:
        """Twelve-month projection per series: linear trend plus monthly effect.

        Fitted on up to the last 36 observations. Series with fewer than six
        points get their mean carried forward, because a trend through three
        points is noise dressed as a projection.
        """
        rows: list[dict[str, Any]] = []

        for (state_code, state_name, variable), group in self._history.groupby(
            ["state_code", "state_name", "variable"], sort=False
        ):
            series = group.sort_values("date").tail(36)
            values = series["value"].to_numpy(dtype=float)
            if len(values) == 0:
                continue

            last_date = series["date"].iloc[-1]
            future = pd.date_range(last_date + pd.offsets.MonthBegin(1),
                                   periods=FORECAST_MONTHS, freq="MS")

            if len(values) < 6:
                predictions = np.full(FORECAST_MONTHS, values.mean())
            else:
                x = np.arange(len(values), dtype=float)
                slope, intercept = np.polyfit(x, values, 1)
                residuals = values - (slope * x + intercept)

                # Month-of-year effect, so a monsoon-driven series keeps its shape.
                months = series["date"].dt.month.to_numpy()
                effect = {m: residuals[months == m].mean() for m in np.unique(months)}

                future_x = np.arange(len(values), len(values) + FORECAST_MONTHS, dtype=float)
                predictions = slope * future_x + intercept
                predictions += np.array([effect.get(d.month, 0.0) for d in future])

            for date, value in zip(future, predictions):
                rows.append({
                    "date": date,
                    "state_code": state_code,
                    "state_name": state_name,
                    "variable": variable,
                    "forecast": float(max(0.0, round(value, 2))),
                })

        frame = pd.DataFrame(rows)
        log.info("Computed %s baseline forecast points", f"{len(frame):,}")
        return frame

    # --------------------------------------------------------------- lookups
    @property
    def available(self) -> bool:
        return not self._forecast.empty

    def get_states(self) -> list[dict[str, str]]:
        """States and union territories present in the data, with real codes."""
        if self._history.empty:
            return []
        subset = (
            self._history[["state_code", "state_name"]]
            .drop_duplicates()
            .sort_values("state_name")
        )
        return [
            {"state_code": str(row.state_code), "state_name": str(row.state_name)}
            for row in subset.itertuples(index=False)
        ]

    def get_variables(self) -> list[str]:
        if self._history.empty:
            return sorted(DISEASE_MEDICINE_MAPPING)
        return sorted(self._history["variable"].unique().tolist())

    def get_curated_variables(self) -> list[str]:
        """Indicators with a reviewed medicine and dosage attached.

        Procurement decisions should start here. The other indicators forecast
        fine but their quantities rest on a default dosage.
        """
        available = set(self.get_variables())
        return sorted(v for v in DISEASE_MEDICINE_MAPPING if v in available)

    def get_history(self, state_name: str, variables: Optional[list[str]] = None) -> list[dict[str, Any]]:
        """Observed values, so a forecast can be shown against what happened."""
        return self._slice(self._history, state_name, variables, "value")

    def get_state_forecasts(
        self, state_name: str, variables: Optional[list[str] | str] = None
    ) -> list[dict[str, Any]]:
        """Twelve-month projection for a state, optionally filtered.

        `variables` accepts a single string as well as a list. The previous
        version typed it as a list and was called with a string, so `isin`
        iterated the characters and every filtered query returned nothing.
        """
        return self._slice(self._forecast, state_name, variables, "forecast")

    def _slice(
        self,
        frame: pd.DataFrame,
        state_name: str,
        variables: Optional[list[str] | str],
        value_column: str,
    ) -> list[dict[str, Any]]:
        if frame.empty:
            return []

        names = frame["state_name"].astype(str).str.lower()
        target = state_name.strip().lower()
        selected = frame[names == target]
        if selected.empty:
            selected = frame[names.str.contains(target, regex=False, na=False)]
        if selected.empty:
            return []

        if variables:
            wanted = [variables] if isinstance(variables, str) else list(variables)
            selected = selected[selected["variable"].isin(wanted)]

        selected = selected.sort_values(["variable", "date"])
        records = selected.to_dict(orient="records")
        for record in records:
            record["date"] = pd.Timestamp(record["date"]).date().isoformat()
            record["method"] = self.method if value_column == "forecast" else "observed"
        return records

    # ------------------------------------------------------------- stockouts
    def get_stockout_alerts(
        self,
        state_name: Optional[str] = None,
        variables: Optional[list[str] | str] = None,
        curated_only: bool = True,
    ) -> list[dict[str, Any]]:
        """Where twelve-month predicted demand exceeds estimated stock.

        `curated_only` defaults to True: an alert built on a reviewed dosage is
        actionable, one built on the default dosage of ten units per case is a
        prompt to review the mapping, and mixing them in one list invites
        ordering against a number nobody checked.
        """
        if self._forecast.empty:
            return []

        frame = self._forecast
        if state_name:
            names = frame["state_name"].astype(str).str.lower()
            frame = frame[names == state_name.strip().lower()]

        if variables:
            wanted = [variables] if isinstance(variables, str) else list(variables)
            frame = frame[frame["variable"].isin(wanted)]
        elif curated_only:
            frame = frame[frame["variable"].isin(DISEASE_MEDICINE_MAPPING)]

        if frame.empty:
            return []

        totals = frame.groupby(["state_name", "variable"], as_index=False)["forecast"].sum()

        alerts: list[dict[str, Any]] = []
        for row in totals.itertuples(index=False):
            info = DISEASE_MEDICINE_MAPPING.get(row.variable) or _fallback(row.variable)
            cases = float(row.forecast)

            required = int(cases * info["dose_per_case"])
            total_required = required + int(required * SAFETY_STOCK_FRACTION)
            if total_required <= 0:
                continue

            ratio = _stock_ratio(str(row.state_name), str(row.variable))
            on_hand = int(total_required * ratio)
            deficit = total_required - on_hand
            if deficit <= 0:
                continue

            alerts.append({
                "state_name": row.state_name,
                "variable": row.variable,
                "disease": info["disease"],
                "medicine": info["medicine"],
                "dose_per_case": info["dose_per_case"],
                "curated_dosage": info.get("curated", True),
                "forecast_cases": round(cases, 1),
                "required_quantity": total_required,
                "estimated_stock": on_hand,
                "deficit": deficit,
                "unit": info["unit"],
                "risk_level": "CRITICAL" if ratio < 0.60 else "HIGH" if ratio < 0.80 else "MODERATE",
                "estimated_days_cover": int(ratio * 365),
                "forecast_method": self.method,
                "stock_source": "estimated",
            })

        order = {"CRITICAL": 0, "HIGH": 1, "MODERATE": 2}
        alerts.sort(key=lambda a: (order[a["risk_level"]], -a["deficit"]))
        return alerts

    def summary(self) -> dict[str, Any]:
        """What the dashboard header needs to state its own provenance."""
        if self._history.empty:
            return {"loaded": False}
        return {
            "loaded": True,
            "forecast_method": self.method,
            "observations": int(len(self._history)),
            "states": int(self._history["state_name"].nunique()),
            "indicators": int(self._history["variable"].nunique()),
            "curated_indicators": len(self.get_curated_variables()),
            "history_from": self._history["date"].min().date().isoformat(),
            "history_to": self._history["date"].max().date().isoformat(),
            "forecast_months": FORECAST_MONTHS,
        }


engine = ForecastingEngine()
