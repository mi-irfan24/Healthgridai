"""HealthGrid AI unified API.

One FastAPI application over the forecasting engine, the procurement planner and
the clinical surfaces.

Changes from the uploaded version, all explained in ANALYSIS.md: the forecast
filter accepts a single variable without silently matching nothing, CORS is
restricted rather than open to every origin, and the health endpoint reports
what is actually loaded instead of a fixed list of service names.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .clinical import LANGUAGES, answer_question, draft_radiology_read, rank_facilities
from .forecasting import DISEASE_MEDICINE_MAPPING, engine
from .procurement import AGENT_ROSTER, plan_for_state

logging.basicConfig(
    level=os.environ.get("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
log = logging.getLogger("healthgrid")

# Open CORS on a service that will hold health data is not a default worth
# keeping. Set ALLOWED_ORIGINS to your dashboard host in deployment.
ALLOWED_ORIGINS = [
    origin.strip()
    for origin in os.environ.get("ALLOWED_ORIGINS", "http://localhost:8501").split(",")
    if origin.strip()
]

app = FastAPI(
    title="HealthGrid AI",
    description=(
        "Disease burden forecasting, medicine demand and procurement planning for "
        "India's public health network. Clinical endpoints return demonstration "
        "fixtures and are marked as such in every response."
    ),
    version="3.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

API = "/api/v1"


# ---------------------------------------------------------------- system
@app.get("/healthz", tags=["system"])
def healthz() -> dict[str, Any]:
    """Readiness, plus what the forecasting engine actually has loaded."""
    data = engine.summary()
    return {
        "status": "ok" if data.get("loaded") else "degraded",
        "version": "3.0.0",
        "data": data,
        "clinical_endpoints": "demonstration fixtures",
    }


@app.get(f"{API}/meta", tags=["system"])
def meta() -> dict[str, Any]:
    """Everything the dashboard needs to describe its own provenance."""
    return {
        "data": engine.summary(),
        "languages": LANGUAGES,
        "procurement_agents": [{"role": role, "goal": goal} for role, goal in AGENT_ROSTER],
        "curated_medicines": len(DISEASE_MEDICINE_MAPPING),
    }


# ----------------------------------------------------------- forecasting
@app.get(f"{API}/forecasting/states", tags=["forecasting"])
def list_states() -> dict[str, Any]:
    """States and union territories in the data, with their real census codes."""
    states = engine.get_states()
    return {"count": len(states), "states": states}


@app.get(f"{API}/forecasting/variables", tags=["forecasting"])
def list_variables(curated_only: bool = False) -> dict[str, Any]:
    """Health indicators available for projection.

    `curated_only=true` returns just those with a reviewed medicine and dosage,
    which is where a procurement conversation should start.
    """
    variables = engine.get_curated_variables() if curated_only else engine.get_variables()
    return {"count": len(variables), "curated_only": curated_only, "variables": variables}


@app.get(f"{API}/forecasting/history", tags=["forecasting"])
def get_history(
    state: str,
    variable: Optional[list[str]] = Query(default=None),
) -> dict[str, Any]:
    """Observed monthly values, so a projection can be read against the past."""
    records = engine.get_history(state, variable)
    if not records:
        raise HTTPException(status_code=404, detail=f"No history for state '{state}'")
    return {"state": state, "count": len(records), "history": records}


@app.get(f"{API}/forecasting/predict", tags=["forecasting"])
def predict(
    state: str,
    variable: Optional[list[str]] = Query(
        default=None,
        description="Repeat the parameter for several indicators. A single value works too.",
    ),
) -> dict[str, Any]:
    """Twelve-month projection for a state."""
    records = engine.get_state_forecasts(state, variable)
    if not records:
        raise HTTPException(
            status_code=404,
            detail=f"No forecast for state '{state}'"
                   + (f" and indicator(s) {variable}" if variable else ""),
        )
    return {
        "state": state,
        "method": engine.method,
        "count": len(records),
        "forecasts": records,
    }


@app.get(f"{API}/forecasting/stockout-alerts", tags=["forecasting"])
def stockout_alerts(
    state: Optional[str] = None,
    variable: Optional[list[str]] = Query(default=None),
    curated_only: bool = True,
) -> dict[str, Any]:
    """Where twelve-month predicted demand exceeds estimated stock."""
    alerts = engine.get_stockout_alerts(state, variable, curated_only=curated_only)
    return {
        "state": state,
        "forecast_method": engine.method,
        "stock_source": "estimated pending DVDMS integration",
        "total_alerts": len(alerts),
        "critical_alerts": sum(1 for a in alerts if a["risk_level"] == "CRITICAL"),
        "alerts": alerts,
    }


class ProcurementRequest(BaseModel):
    state: str = Field(description="State or union territory name, for example Tamil Nadu")
    top_n: int = Field(default=12, ge=1, le=50)


@app.post(f"{API}/forecasting/procurement-plan", tags=["forecasting"])
def procurement_plan(body: ProcurementRequest) -> dict[str, Any]:
    """Prioritised procurement plan. Says whether an agent or the heuristic wrote it."""
    return plan_for_state(body.state, body.top_n)


# -------------------------------------------------------------- clinical
class ReferralRequest(BaseModel):
    patient_id: str
    required_specialties: list[str] = Field(default_factory=list)
    required_capabilities: list[str] = Field(default_factory=list)
    urgency: str = Field(default="routine", pattern="^(emergency|priority|routine)$")
    origin_facility_id: str


@app.post(f"{API}/referral/recommendations", tags=["clinical (demonstration)"])
def referral_recommendations(body: ReferralRequest) -> dict[str, Any]:
    """Ranked destinations. Demonstration fixture; real weights."""
    return rank_facilities(body.required_specialties, body.required_capabilities, body.urgency)


class AskRequest(BaseModel):
    patient_id: str
    question: str = Field(min_length=2, max_length=500)
    language: str = "hi"


@app.post(f"{API}/assistant/ask", tags=["clinical (demonstration)"])
def assistant_ask(body: AskRequest) -> dict[str, Any]:
    """Patient question in one of twelve languages. Refusal rules are real."""
    result = answer_question(body.question, body.language)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result)
    return result


@app.get(f"{API}/assistant/languages", tags=["clinical (demonstration)"])
def assistant_languages() -> dict[str, str]:
    return LANGUAGES


@app.post(f"{API}/radiology/draft", tags=["clinical (demonstration)"])
def radiology_draft(filename: str = "") -> dict[str, Any]:
    """Preliminary imaging read. Demonstration fixture; always requires signature."""
    return draft_radiology_read(filename)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "backend.main:app",
        host="0.0.0.0",
        port=int(os.environ.get("PORT", "8000")),
        reload=bool(os.environ.get("RELOAD")),
    )
