"""Vertex AI access for clinical drafting and grounding.

Three hard rules are enforced here rather than trusted to prompts:
  1. Output is always marked preliminary. Nothing reaches the record unsigned.
  2. Responses are schema-validated. A free-text blob cannot become a
     DiagnosticReport.
  3. Model id and prompt version travel with every result, so any report can be
     traced back to what produced it.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any

import vertexai
from vertexai.generative_models import GenerationConfig, GenerativeModel, Part

from .config import settings

log = logging.getLogger(__name__)

PROMPT_VERSION = "2026-09-radiology-v3"

_SAFETY_PREAMBLE = (
    "You are assisting a qualified clinician in an Indian public health facility. "
    "You produce preliminary observations only. You never state a definitive "
    "diagnosis, never prescribe, and never recommend a dose. If image quality or "
    "the supplied context is insufficient, say so explicitly and stop. "
    "Respond with JSON only, no prose and no markdown fences."
)

_RADIOLOGY_SCHEMA = {
    "type": "object",
    "properties": {
        "modality": {"type": "string"},
        "quality": {"type": "string", "enum": ["adequate", "suboptimal", "insufficient"]},
        "findings": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "text": {"type": "string"},
                    "confidence": {"type": "number"},
                    "region": {"type": "string"},
                },
                "required": ["text", "confidence"],
            },
        },
        "impression": {"type": "string"},
        "critical": {"type": "boolean"},
        "suggested_next_steps": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["modality", "quality", "findings", "impression", "critical"],
}


@dataclass
class ModelResult:
    payload: dict[str, Any]
    model: str
    prompt_version: str = PROMPT_VERSION
    warnings: list[str] = field(default_factory=list)

    @property
    def is_usable(self) -> bool:
        return self.payload.get("quality") != "insufficient"


_initialised = False


def _init() -> None:
    global _initialised
    if not _initialised:
        cfg = settings()
        vertexai.init(project=cfg.project, location=cfg.region)
        _initialised = True


def _parse_json(text: str) -> dict[str, Any]:
    """Models occasionally wrap JSON in fences despite instructions."""
    cleaned = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise ValueError(f"model returned unparseable output: {exc}") from exc


def draft_radiology_report(
    image_bytes: bytes,
    mime_type: str,
    clinical_context: str,
    modality_hint: str = "",
) -> ModelResult:
    """Produce a preliminary imaging read for a radiologist to verify."""
    _init()
    cfg = settings()
    model = GenerativeModel(cfg.gemini_model, system_instruction=_SAFETY_PREAMBLE)

    prompt = (
        f"Modality hint: {modality_hint or 'unknown'}.\n"
        f"Relevant clinical context: {clinical_context or 'none supplied'}.\n"
        "Describe what is visible, assign a confidence between 0 and 1 to each "
        "finding, and flag critical=true only for findings needing same-day action."
    )

    response = model.generate_content(
        [Part.from_data(image_bytes, mime_type=mime_type), prompt],
        generation_config=GenerationConfig(
            temperature=0.1,  # clinical drafting wants reproducibility, not variety
            max_output_tokens=1400,
            response_mime_type="application/json",
            response_schema=_RADIOLOGY_SCHEMA,
        ),
    )

    payload = _parse_json(response.text)
    warnings: list[str] = []
    if payload.get("quality") == "suboptimal":
        warnings.append("Image quality flagged suboptimal by the model.")
    if not payload.get("findings"):
        warnings.append("Model returned no findings; treat as unread.")

    log.info(
        "radiology draft produced",
        extra={"context": {
            "model": cfg.gemini_model,
            "critical": payload.get("critical"),
            "findings": len(payload.get("findings", [])),
        }},
    )
    return ModelResult(payload=payload, model=cfg.gemini_model, warnings=warnings)


def summarise_record(record: dict[str, Any], language: str = "en") -> ModelResult:
    """Clinical digest of a longitudinal record for the workspace right rail."""
    _init()
    cfg = settings()
    model = GenerativeModel(cfg.gemini_model, system_instruction=_SAFETY_PREAMBLE)

    schema = {
        "type": "object",
        "properties": {
            "summary": {"type": "string"},
            "active_problems": {"type": "array", "items": {"type": "string"}},
            "care_gaps": {"type": "array", "items": {"type": "string"}},
            "facilities_involved": {"type": "array", "items": {"type": "string"}},
        },
        "required": ["summary", "active_problems", "care_gaps"],
    }

    response = model.generate_content(
        json.dumps({"language": language, "record": _trim_record(record)}, default=str),
        generation_config=GenerationConfig(
            temperature=0.1,
            max_output_tokens=900,
            response_mime_type="application/json",
            response_schema=schema,
        ),
    )
    return ModelResult(payload=_parse_json(response.text), model=cfg.gemini_model)


def explain_for_patient(resource: dict[str, Any], language: str) -> str:
    """Plain-language explanation of one report or prescription.

    Reading level is deliberately low. This text is read aloud over IVR to
    people who may not read at all.
    """
    _init()
    cfg = settings()
    model = GenerativeModel(
        cfg.gemini_model,
        system_instruction=(
            "Explain the supplied health record to the patient in simple words, "
            f"in {language}. Use short sentences. Do not add advice the record "
            "does not contain. Do not change any dose or instruction. End by "
            "telling the patient to ask their health worker if unsure. "
            "Return plain text only."
        ),
    )
    response = model.generate_content(
        json.dumps(resource, default=str),
        generation_config=GenerationConfig(temperature=0.2, max_output_tokens=600),
    )
    return response.text.strip()


def _trim_record(record: dict[str, Any], keep: int = 12) -> dict[str, Any]:
    """Keep the prompt inside a sane budget.

    A five-year NCD history will blow the context window and cost money for no
    clinical gain -- the recent slice is what changes the decision.
    """
    trimmed: dict[str, Any] = {}
    for key, value in record.items():
        trimmed[key] = value[:keep] if isinstance(value, list) else value
    return trimmed
