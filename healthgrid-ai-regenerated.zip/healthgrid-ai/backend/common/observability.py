"""Structured logging that Cloud Logging can parse without a custom parser.

Two rules this module enforces:
  1. Log lines are JSON, so severity and trace show up as first-class fields.
  2. Nothing that looks like PHI goes into a log message. Callers pass
     identifiers through `redact` and get a stable hash instead.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import sys
from typing import Any


_TRACE_HEADER = "X-Cloud-Trace-Context"


class CloudLoggingFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "severity": record.levelname,
            "message": record.getMessage(),
            "logger": record.name,
        }
        trace = getattr(record, "trace", None)
        if trace:
            project = os.environ.get("GCP_PROJECT", "")
            payload["logging.googleapis.com/trace"] = f"projects/{project}/traces/{trace}"
        extra = getattr(record, "context", None)
        if extra:
            payload["context"] = extra
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


def configure(level: str = "INFO") -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(CloudLoggingFormatter())
    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(level.upper())
    # These libraries log request bodies at DEBUG, which would put PHI in logs.
    for noisy in ("google.auth", "urllib3", "google.api_core"):
        logging.getLogger(noisy).setLevel("WARNING")


def redact(value: str | None) -> str:
    """Stable, non-reversible reference for an identifier.

    Used so we can correlate log lines for the same patient during an incident
    without writing an ABHA number or name into the log stream.
    """
    if not value:
        return "none"
    return "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]


def trace_id(headers) -> str | None:
    raw = headers.get(_TRACE_HEADER) if headers else None
    return raw.split("/")[0] if raw else None
