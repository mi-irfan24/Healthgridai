"""Shared building blocks for HealthGrid services.

Nothing in here talks to a specific service's business logic. If you find
yourself importing a service module into common, the dependency is backwards.
"""
