"""Thin authenticated clients.

The Healthcare API has no first-class Python client for FHIR REST, so we use an
authorised session against the REST surface. That is the documented approach and
it keeps the FHIR payloads as plain dicts, which is what the callers want.
"""
from __future__ import annotations

import logging
from functools import lru_cache

import google.auth
import google.auth.transport.requests
import requests
from google.auth.transport.requests import AuthorizedSession

log = logging.getLogger(__name__)

_SCOPES = ["https://www.googleapis.com/auth/cloud-platform"]


@lru_cache(maxsize=1)
def authorized_session() -> AuthorizedSession:
    credentials, _ = google.auth.default(scopes=_SCOPES)
    session = AuthorizedSession(credentials)
    session.headers.update({"User-Agent": "healthgrid/1.0"})
    return session


def id_token_for(audience: str) -> str:
    """Mint an OIDC token for service-to-service Cloud Run calls."""
    from google.auth import compute_engine, fetch_id_token
    from google.auth.transport.requests import Request

    try:
        return fetch_id_token(Request(), audience)
    except Exception:  # pragma: no cover - depends on runtime identity
        log.warning("fetch_id_token failed; falling back to metadata server")
        credentials = compute_engine.IDTokenCredentials(
            google.auth.transport.requests.Request(),
            target_audience=audience,
        )
        credentials.refresh(google.auth.transport.requests.Request())
        return credentials.token


class TransientError(RuntimeError):
    """Retryable failure. Pub/Sub should redeliver; HTTP callers get a 503."""


def raise_for_status(response: requests.Response, context: str) -> None:
    if response.status_code >= 500:
        raise TransientError(f"{context}: upstream {response.status_code}")
    if response.status_code >= 400:
        # Deliberately do not log the body -- FHIR error payloads echo the
        # submitted resource, which is PHI.
        raise RuntimeError(f"{context}: rejected with {response.status_code}")
