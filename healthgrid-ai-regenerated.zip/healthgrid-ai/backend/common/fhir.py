"""FHIR R4 access against the Cloud Healthcare API.

Every read goes through `FhirClient`, which takes a consent token. That is not
decoration: it is the single choke point where we can prove no clinical payload
was returned without an active consent artefact.
"""
from __future__ import annotations

import logging
from typing import Any
from urllib.parse import urlencode

from .config import settings
from .gcp import authorized_session, raise_for_status
from .observability import redact

log = logging.getLogger(__name__)

JSON_FHIR = "application/fhir+json"


class ConsentRequired(PermissionError):
    """No active consent artefact covers this read. Callers must not retry."""


class FhirClient:
    def __init__(self, consent_ref: str | None = None) -> None:
        self._base = settings().fhir_base_url
        self._session = authorized_session()
        self._consent_ref = consent_ref

    # ---------------------------------------------------------------- reads
    def _guard(self, resource_type: str) -> None:
        # Consent gates patient-identifiable resources. Registry-style resources
        # (facilities, terminology) are not patient data and need no artefact.
        open_types = {"Organization", "Location", "HealthcareService", "ValueSet", "CodeSystem"}
        if resource_type in open_types:
            return
        if not self._consent_ref:
            raise ConsentRequired(f"read of {resource_type} attempted without a consent artefact")

    def read(self, resource_type: str, resource_id: str) -> dict[str, Any]:
        self._guard(resource_type)
        url = f"{self._base}/{resource_type}/{resource_id}"
        response = self._session.get(url, headers={"Accept": JSON_FHIR})
        raise_for_status(response, f"read {resource_type}")
        return response.json()

    def search(self, resource_type: str, params: dict[str, Any]) -> list[dict[str, Any]]:
        """Returns the resources from a bundle, following pagination."""
        self._guard(resource_type)
        url = f"{self._base}/{resource_type}?{urlencode(params)}"
        resources: list[dict[str, Any]] = []

        while url:
            response = self._session.get(url, headers={"Accept": JSON_FHIR})
            raise_for_status(response, f"search {resource_type}")
            bundle = response.json()
            resources.extend(entry["resource"] for entry in bundle.get("entry", []))
            url = next(
                (link["url"] for link in bundle.get("link", []) if link.get("relation") == "next"),
                None,
            )
        return resources

    # --------------------------------------------------------------- writes
    def create(self, resource: dict[str, Any]) -> dict[str, Any]:
        resource_type = resource["resourceType"]
        url = f"{self._base}/{resource_type}"
        response = self._session.post(
            url, json=resource, headers={"Content-Type": JSON_FHIR, "Accept": JSON_FHIR}
        )
        raise_for_status(response, f"create {resource_type}")
        created = response.json()
        log.info(
            "fhir resource created",
            extra={"context": {"type": resource_type, "id": created.get("id")}},
        )
        return created

    def update(self, resource: dict[str, Any]) -> dict[str, Any]:
        resource_type, resource_id = resource["resourceType"], resource["id"]
        url = f"{self._base}/{resource_type}/{resource_id}"
        response = self._session.put(
            url, json=resource, headers={"Content-Type": JSON_FHIR, "Accept": JSON_FHIR}
        )
        raise_for_status(response, f"update {resource_type}")
        return response.json()

    # ------------------------------------------------------- record assembly
    def longitudinal_record(self, patient_id: str, max_per_type: int = 50) -> dict[str, Any]:
        """Assemble the cross-facility view the clinician workspace renders.

        Deliberately bounded: a chronic patient can have thousands of
        Observations, and a clinician needs the recent ones, not all of them.
        """
        self._guard("Patient")
        patient = self.read("Patient", patient_id)
        record: dict[str, Any] = {"patient": patient}

        queries = {
            "encounters": ("Encounter", {"subject": f"Patient/{patient_id}", "_sort": "-date"}),
            "conditions": ("Condition", {"subject": f"Patient/{patient_id}", "_sort": "-recorded-date"}),
            "observations": ("Observation", {"subject": f"Patient/{patient_id}", "_sort": "-date"}),
            "medications": ("MedicationRequest", {"subject": f"Patient/{patient_id}", "_sort": "-authoredon"}),
            "reports": ("DiagnosticReport", {"subject": f"Patient/{patient_id}", "_sort": "-date"}),
            "referrals": ("ServiceRequest", {"subject": f"Patient/{patient_id}", "_sort": "-authored"}),
            "immunizations": ("Immunization", {"patient": f"Patient/{patient_id}", "_sort": "-date"}),
        }

        for key, (resource_type, params) in queries.items():
            params = {**params, "_count": str(max_per_type)}
            try:
                record[key] = self.search(resource_type, params)
            except RuntimeError:
                # One missing resource type must not fail the whole record.
                # A PHC with no imaging is normal, not an error.
                log.warning("partial record", extra={"context": {"missing": resource_type}})
                record[key] = []

        log.info(
            "longitudinal record assembled",
            extra={"context": {"patient": redact(patient_id), "sections": len(record)}},
        )
        return record


def patient_display(patient: dict[str, Any]) -> str:
    """Human-readable label. Used in clinician-facing output only."""
    names = patient.get("name") or []
    if not names:
        return patient.get("id", "unknown")
    name = names[0]
    given = " ".join(name.get("given", []))
    return f"{given} {name.get('family', '')}".strip()
