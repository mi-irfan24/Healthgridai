"""Runtime configuration.

Every value comes from the environment, which Terraform populates. There are no
defaults for resource paths on purpose: a service that silently points at the
wrong FHIR store is worse than one that refuses to start.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache


class ConfigError(RuntimeError):
    """Raised at startup when a required environment variable is missing."""


def _require(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise ConfigError(
            f"{name} is not set. Cloud Run gets this from Terraform; "
            f"locally, copy .env.example to .env and source it."
        )
    return value


def _optional(name: str, default: str) -> str:
    return os.environ.get(name) or default


@dataclass(frozen=True)
class Settings:
    project: str
    region: str
    fhir_store: str
    dicom_store: str
    raw_bucket: str
    curated_bucket: str
    gemini_model: str
    env: str
    log_level: str

    @property
    def fhir_base_url(self) -> str:
        return f"https://healthcare.googleapis.com/v1/{self.fhir_store}/fhir"

    @property
    def dicom_base_url(self) -> str:
        return f"https://healthcare.googleapis.com/v1/{self.dicom_store}/dicomWeb"

    @property
    def is_production(self) -> bool:
        return self.env == "prod"


@lru_cache(maxsize=1)
def settings() -> Settings:
    return Settings(
        project=_require("GCP_PROJECT"),
        region=_optional("GCP_REGION", "asia-south1"),
        fhir_store=_require("FHIR_STORE"),
        dicom_store=_optional("DICOM_STORE", ""),
        raw_bucket=_optional("RAW_BUCKET", ""),
        curated_bucket=_optional("CURATED_BUCKET", ""),
        gemini_model=_optional("GEMINI_MODEL", "gemini-2.0-flash"),
        env=_optional("ENV", "dev"),
        log_level=_optional("LOG_LEVEL", "INFO"),
    )
