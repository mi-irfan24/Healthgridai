"""ABDM gateway client: ABHA verification and consent artefacts.

This is a boundary shim. The ABDM sandbox and production endpoints differ in
host and in a few payload details, so the base URL is configuration and the
payload builders are in one place where they can be updated when the spec moves.

Verify every payload below against the current ABDM HIU specification before
going live -- the spec has changed more than once and this code reflects the
M2 gateway shape.
"""
from __future__ import annotations

import logging
import os
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

import requests

log = logging.getLogger(__name__)

_TOKEN_SKEW_SECONDS = 60


class AbdmError(RuntimeError):
    pass


@dataclass
class ConsentArtefact:
    artefact_id: str
    patient_abha: str
    purpose: str
    expires_at: datetime
    hi_types: list[str]

    @property
    def is_active(self) -> bool:
        return datetime.now(timezone.utc) < self.expires_at

    def covers(self, hi_type: str) -> bool:
        return self.is_active and hi_type in self.hi_types


class AbdmClient:
    def __init__(
        self,
        base_url: str | None = None,
        client_id: str | None = None,
        client_secret: str | None = None,
        timeout: int = 20,
    ) -> None:
        self.base_url = (base_url or os.environ.get("ABDM_GATEWAY_BASE_URL", "")).rstrip("/")
        self.client_id = client_id or os.environ.get("ABDM_CLIENT_ID", "")
        self.client_secret = client_secret or os.environ.get("ABDM_CLIENT_SECRET", "")
        self.timeout = timeout
        self._token: str | None = None
        self._token_expiry: float = 0.0

        if not self.base_url:
            log.warning("ABDM base url not configured; client will operate in stub mode")

    # ---------------------------------------------------------------- auth
    def _access_token(self) -> str:
        if self._token and time.time() < self._token_expiry - _TOKEN_SKEW_SECONDS:
            return self._token

        response = requests.post(
            f"{self.base_url}/v0.5/sessions",
            json={"clientId": self.client_id, "clientSecret": self.client_secret},
            timeout=self.timeout,
        )
        if response.status_code != 200:
            raise AbdmError(f"session request failed with {response.status_code}")

        body = response.json()
        self._token = body["accessToken"]
        self._token_expiry = time.time() + int(body.get("expiresIn", 1200))
        return self._token

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._access_token()}",
            "X-CM-ID": os.environ.get("ABDM_CM_ID", "sbx"),
            "X-HIU-ID": os.environ.get("ABDM_HIU_ID", ""),
            "REQUEST-ID": str(uuid.uuid4()),
            "TIMESTAMP": datetime.now(timezone.utc).isoformat(),
            "Content-Type": "application/json",
        }

    # ------------------------------------------------------------- consent
    def request_consent(
        self,
        abha_address: str,
        purpose_code: str = "CAREMGT",
        hi_types: list[str] | None = None,
        validity_days: int = 30,
    ) -> str:
        """Raise a consent request. Returns the gateway request id.

        The citizen then approves or denies in their ABHA app. Nothing is
        readable until the artefact notification arrives on the callback.
        """
        hi_types = hi_types or ["DiagnosticReport", "Prescription", "OPConsultation", "ImmunizationRecord"]
        now = datetime.now(timezone.utc)

        payload = {
            "requestId": str(uuid.uuid4()),
            "timestamp": now.isoformat(),
            "consent": {
                "purpose": {"text": "Care management", "code": purpose_code},
                "patient": {"id": abha_address},
                "hiu": {"id": os.environ.get("ABDM_HIU_ID", "")},
                "requester": {"name": "HealthGrid AI", "identifier": {"type": "REGNO", "value": os.environ.get("HPR_ID", "")}},
                "hiTypes": hi_types,
                "permission": {
                    "accessMode": "VIEW",
                    "dateRange": {
                        "from": (now - timedelta(days=365 * 5)).isoformat(),
                        "to": now.isoformat(),
                    },
                    "dataEraseAt": (now + timedelta(days=validity_days)).isoformat(),
                    "frequency": {"unit": "HOUR", "value": 1, "repeats": 0},
                },
            },
        }

        response = requests.post(
            f"{self.base_url}/v0.5/consent-requests/init",
            json=payload,
            headers=self._headers(),
            timeout=self.timeout,
        )
        if response.status_code not in (200, 202):
            raise AbdmError(f"consent init failed with {response.status_code}")

        log.info("consent requested", extra={"context": {"purpose": purpose_code}})
        return payload["requestId"]

    def fetch_artefact(self, artefact_id: str) -> ConsentArtefact:
        response = requests.post(
            f"{self.base_url}/v0.5/consents/fetch",
            json={
                "requestId": str(uuid.uuid4()),
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "consentId": artefact_id,
            },
            headers=self._headers(),
            timeout=self.timeout,
        )
        if response.status_code not in (200, 202):
            raise AbdmError(f"artefact fetch failed with {response.status_code}")

        body = response.json().get("consent", {}).get("consentDetail", {})
        erase_at = body.get("permission", {}).get("dataEraseAt")

        return ConsentArtefact(
            artefact_id=artefact_id,
            patient_abha=body.get("patient", {}).get("id", ""),
            purpose=body.get("purpose", {}).get("code", ""),
            expires_at=datetime.fromisoformat(erase_at) if erase_at else datetime.now(timezone.utc),
            hi_types=body.get("hiTypes", []),
        )
