# Data

## `state_monthly_indicators.csv.gz` (1.4 MB, committed)

State-level monthly totals for 286 health indicators across 36 states and union
territories, January 2017 to May 2021. 263,978 observations in long format.

```
date,state_code,state_name,variable,value
2017-01-01,33,Tamil Nadu,child_bcg,48231
```

`state_code` is the census code, taken from the source file. Tamil Nadu is 33,
Kerala 32, Bihar 10.

Derived from the raw sub-district extract by `scripts/build_dataset.py`. Two
things happen in that reduction and both matter:

**The month is reconstructed.** The source encodes the month in the day
position: `2018-01-04` is April 2018. Parsed directly, every record in the file
lands in January, which is what the earlier Prophet training did. The script
rebuilds the period from the year and the day component.

**Only the Total sector is kept.** The source repeats each row five times, as
Public, Private, Rural, Urban and Total. Public plus Private re-sums to Total,
and so does Rural plus Urban, so including them would triple-count every case.

## `major-health-indicators-subdistrict-level.csv` (411 MB, not committed)

The raw extract. Not required at runtime — the platform only ever reads
state-level monthly totals. Keep it outside the repository and point the build
script at it:

```bash
python scripts/build_dataset.py --source /path/to/major-health-indicators-subdistrict-level.csv
```

Sub-district granularity is preserved in the source if a future block-level view
needs it. Nothing in the current application reads below state level.

## `prophet_forecasts.csv.gz` (not committed)

Written by `scripts/train_prophet.py`. When present the engine uses it and
reports `method: "prophet"`; when absent it computes a trend-and-seasonal
baseline in process and reports `method: "baseline"`. The dashboard states which
one it is using, every time.

## What is not in here

No patient-level data, no facility identifiers, no ABHA numbers. Everything is
aggregated to state and month. If patient-level data ever enters this repository,
something has gone wrong with the architecture — that belongs in the Cloud
Healthcare API FHIR store under customer-managed keys, not in a CSV.
