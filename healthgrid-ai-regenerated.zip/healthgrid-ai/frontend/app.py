"""HealthGrid AI dashboard.

Streamlit interface over the forecasting engine, styled for an Indian public
health audience: National Health Mission green, a saffron accent used only for
things needing action, and Devanagari-capable type.

Three principles carried from the review:
  * Every number says where it came from. A projection is labelled a projection
    and an estimated stock figure is labelled an estimate, wherever it appears.
  * Demonstration screens say so. Referral, assistant and radiology are
    fixtures; a committee shown a live-looking panel will assume it is live.
  * Nothing claims a service is online without checking it.
"""
from __future__ import annotations

import os
import sys
import traceback

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(
    page_title="HealthGrid AI — National Health Resource Platform",
    page_icon="🇮🇳",
    layout="wide",
    initial_sidebar_state="expanded",
)

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if REPO not in sys.path:
    sys.path.insert(0, REPO)

try:
    from backend.clinical import LANGUAGES, answer_question, draft_radiology_read, rank_facilities
    from backend.forecasting import SAFETY_STOCK_FRACTION, engine
    from backend.procurement import AGENT_ROSTER, plan_for_state
except Exception:
    st.error("The forecasting backend did not load.")
    st.code(traceback.format_exc())
    st.info("Run `python scripts/build_dataset.py --source <raw csv>` if the dataset is missing.")
    st.stop()

# National Health Mission green with a saffron accent reserved for action.
GREEN, SAFFRON, NAVY, INK = "#046A38", "#F47B20", "#0B3C5D", "#1B2B34"

st.markdown(f"""
<style>
  html, body, [class*="css"] {{
    font-family: 'Noto Sans', 'Noto Sans Devanagari', 'Segoe UI', sans-serif;
  }}
  .hg-band {{
    border-left: 5px solid {GREEN};
    background: #F3F8F5;
    padding: 0.9rem 1.2rem;
    border-radius: 3px;
    margin-bottom: 1rem;
  }}
  .hg-title {{ font-size: 1.6rem; font-weight: 700; color: {NAVY}; margin: 0; }}
  .hg-sub {{ color: #52616B; font-size: 0.95rem; margin-top: 0.25rem; }}
  .hg-note {{
    border-left: 4px solid {SAFFRON};
    background: #FFF6EE;
    padding: 0.7rem 1rem;
    border-radius: 3px;
    font-size: 0.88rem;
    color: #6B4415;
  }}
  .hg-demo {{
    border: 1px dashed {SAFFRON};
    background: #FFFBF6;
    padding: 0.7rem 1rem;
    border-radius: 3px;
    font-size: 0.88rem;
    color: #6B4415;
    margin-bottom: 1rem;
  }}
  div[data-testid="stMetricValue"] {{ color: {NAVY}; }}
  .stTabs [data-baseweb="tab-list"] {{ gap: 0.4rem; }}
</style>
""", unsafe_allow_html=True)


@st.cache_data(show_spinner="Reading the indicator history…")
def load_meta():
    return engine.summary()


@st.cache_data(show_spinner="Loading states…")
def load_states():
    return engine.get_states()


@st.cache_data(show_spinner=False)
def load_variables(curated_only: bool):
    return engine.get_curated_variables() if curated_only else engine.get_variables()


@st.cache_data(show_spinner="Projecting the next twelve months…")
def load_series(state: str, variables: tuple):
    chosen = list(variables) or None
    return engine.get_history(state, chosen), engine.get_state_forecasts(state, chosen)


@st.cache_data(show_spinner="Calculating medicine requirements…")
def load_alerts(state: str):
    return engine.get_stockout_alerts(state)


meta = load_meta()
if not meta.get("loaded"):
    st.error("No indicator data found in `data/`. Build it with `scripts/build_dataset.py`.")
    st.stop()

states = load_states()
state_names = [s["state_name"] for s in states]

# --------------------------------------------------------------- sidebar
with st.sidebar:
    st.markdown(f"<div class='hg-title'>HealthGrid AI</div>", unsafe_allow_html=True)
    st.caption("National Health Mission · district health intelligence")
    st.divider()

    default = state_names.index("Tamil Nadu") if "Tamil Nadu" in state_names else 0
    state = st.selectbox("State or union territory", state_names, index=default)
    state_code = next((s["state_code"] for s in states if s["state_name"] == state), "")
    st.caption(f"Census state code {state_code}")

    st.divider()
    curated_only = st.toggle(
        "Indicators with a reviewed medicine only",
        value=True,
        help=(
            f"{meta['curated_indicators']} of {meta['indicators']} indicators have a medicine "
            "and per-case dosage reviewed against standard treatment guidelines. The rest "
            "forecast fine but their quantities rest on a default dosage."
        ),
    )
    options = load_variables(curated_only)
    chosen = st.multiselect(
        "Indicators",
        options,
        default=options[:4] if curated_only else [],
        placeholder=f"Search {len(options)} indicators",
    )

    st.divider()
    st.markdown("**Where the numbers come from**")
    st.caption(
        f"{meta['observations']:,} observed state-months, "
        f"{meta['history_from']} to {meta['history_to']}, "
        f"across {meta['states']} states and {meta['indicators']} indicators."
    )
    if meta["forecast_method"] == "prophet":
        st.success("Forecast: trained Prophet models")
    else:
        st.warning(
            "Forecast: trend and seasonal baseline. "
            "Run `scripts/train_prophet.py` for Prophet models."
        )
    st.caption("Stock positions are estimates until a DVDMS or e-Aushadhi feed is connected.")

# ---------------------------------------------------------------- header
st.markdown(
    f"<div class='hg-band'><div class='hg-title'>Health resource and supply chain intelligence</div>"
    f"<div class='hg-sub'>{state} · twelve-month disease burden projection, medicine demand "
    f"and procurement priorities</div></div>",
    unsafe_allow_html=True,
)

history, forecast = load_series(state, tuple(chosen))
alerts = load_alerts(state)

total_projected = int(sum(r["forecast"] for r in forecast)) if forecast else 0
critical = sum(1 for a in alerts if a["risk_level"] == "CRITICAL")

c1, c2, c3, c4 = st.columns(4)
c1.metric("Projected cases, 12 months", f"{total_projected:,}",
          help="Sum across the selected indicators. A projection, not a count.")
c2.metric("Medicines needing action now", f"{critical}",
          help="Estimated stock below 60% of projected need.")
c3.metric("Shortfalls identified", f"{len(alerts)}")
c4.metric("Indicators selected", f"{len(chosen) or len(load_variables(curated_only))}")

st.divider()

tab_forecast, tab_supply, tab_plan, tab_referral, tab_assistant, tab_imaging = st.tabs([
    "Disease burden", "Medicine demand", "Procurement plan",
    "Referral (demo)", "Patient assistant (demo)", "Imaging draft (demo)",
])

# ------------------------------------------------------- disease burden
with tab_forecast:
    st.subheader(f"Observed burden and projection · {state}")

    if not forecast:
        st.info("No data for this state and indicator combination. Try another state.")
    else:
        hist_df = pd.DataFrame(history)
        fore_df = pd.DataFrame(forecast)
        shown = sorted(fore_df["variable"].unique())[:8]

        if len(fore_df["variable"].unique()) > 8:
            st.caption(f"Charting the first 8 of {fore_df['variable'].nunique()} selected indicators.")

        figure = go.Figure()
        palette = [GREEN, NAVY, "#7B3F00", "#2E6F9E", "#5B8C5A", "#8E5572", "#3D5A6C", "#A15C38"]

        for index, variable in enumerate(shown):
            colour = palette[index % len(palette)]
            if not hist_df.empty:
                series = hist_df[hist_df["variable"] == variable]
                figure.add_trace(go.Scatter(
                    x=pd.to_datetime(series["date"]), y=series["value"],
                    name=f"{variable} (observed)", mode="lines",
                    line=dict(color=colour, width=2),
                ))
            series = fore_df[fore_df["variable"] == variable]
            figure.add_trace(go.Scatter(
                x=pd.to_datetime(series["date"]), y=series["forecast"],
                name=f"{variable} (projected)", mode="lines+markers",
                line=dict(color=colour, width=2, dash="dot"),
            ))

        figure.update_layout(
            height=460, hovermode="x unified",
            plot_bgcolor="white", paper_bgcolor="white",
            xaxis=dict(title="Month", gridcolor="#EDF1F3"),
            yaxis=dict(title="Cases", gridcolor="#EDF1F3"),
            legend=dict(font=dict(size=10), orientation="h", y=-0.22),
            margin=dict(t=10, b=10),
        )
        st.plotly_chart(figure, use_container_width=True)

        st.markdown(
            "<div class='hg-note'>Solid lines are recorded values from the HMIS extract. "
            f"Dotted lines are the {meta['forecast_method']} projection for the next twelve "
            "months. Verify a projection against the field before acting on it.</div>",
            unsafe_allow_html=True,
        )

# -------------------------------------------------------- medicine demand
with tab_supply:
    st.subheader(f"Projected medicine demand against stock · {state}")

    if not alerts:
        st.success(f"No shortfall projected for {state} across the reviewed indicators.")
    else:
        table = pd.DataFrame(alerts)[[
            "disease", "medicine", "forecast_cases", "dose_per_case",
            "required_quantity", "estimated_stock", "deficit", "unit",
            "risk_level", "estimated_days_cover",
        ]].rename(columns={
            "disease": "Disease programme",
            "medicine": "Medicine",
            "forecast_cases": "Projected cases (12 mo)",
            "dose_per_case": "Per case",
            "required_quantity": f"Required (incl. {int(SAFETY_STOCK_FRACTION * 100)}% buffer)",
            "estimated_stock": "Estimated on hand",
            "deficit": "Shortfall",
            "unit": "Unit",
            "risk_level": "Priority",
            "estimated_days_cover": "Days of cover",
        })
        st.dataframe(table, use_container_width=True, hide_index=True)

        st.markdown(
            "<div class='hg-note'><b>How each figure is derived.</b> "
            "Required quantity is the twelve-month projected caseload multiplied by the "
            f"per-case dosage, plus a {int(SAFETY_STOCK_FRACTION * 100)}% safety buffer. "
            "Stock on hand is an estimate derived deterministically per item, so it is stable "
            "between refreshes but it is not a warehouse reading. Connect DVDMS or e-Aushadhi "
            "before any order is raised against these numbers.</div>",
            unsafe_allow_html=True,
        )

# ------------------------------------------------------- procurement plan
with tab_plan:
    st.subheader(f"Procurement priorities · {state}")
    st.caption("Sequential agents: " + " → ".join(role for role, _ in AGENT_ROSTER))

    if st.button(f"Generate the plan for {state}", type="primary"):
        with st.spinner("Building the plan…"):
            result = plan_for_state(state)

        if result["generated_by"] == "crewai-vertex":
            st.success("Written by the Vertex AI agent crew.")
        elif result["generated_by"] == "heuristic":
            st.info(
                "Written by the heuristic planner. CrewAI or Vertex AI credentials are not "
                "available in this environment, so the plan is rule-based and deterministic."
            )

        st.markdown(result.get("plan_markdown", result.get("message", "")))

        if result.get("alerts"):
            with st.expander("Shortfalls the plan was built from"):
                st.dataframe(pd.DataFrame(result["alerts"]), use_container_width=True, hide_index=True)

# ------------------------------------------------------------- referral
with tab_referral:
    st.markdown(
        "<div class='hg-demo'><b>Demonstration screen.</b> The ranking weights and exclusion "
        "rules are the real ones. The facilities are fixtures: this prototype has no facility "
        "registry or bed-availability feed connected.</div>",
        unsafe_allow_html=True,
    )
    st.subheader("Referral and bed matching")

    left, right = st.columns(2)
    with left:
        st.text_input("ABHA number", "12-3456-7890-1234")
        urgency = st.selectbox(
            "How soon",
            ["emergency", "priority", "routine"],
            index=1,
            format_func=lambda u: {
                "emergency": "Emergency — within the hour",
                "priority": "Priority — same day",
                "routine": "Routine",
            }[u],
        )
    with right:
        specialties = st.multiselect(
            "Specialists needed",
            ["Paediatrics", "General surgery", "Obstetrics", "Cardiology", "Endocrinology"],
            default=["Paediatrics"],
        )
        capabilities = st.multiselect(
            "Facilities needed",
            ["blood_bank", "icu", "ot", "dialysis", "nicu_3"],
            default=["blood_bank", "icu"],
        )

    if st.button("Rank the options"):
        result = rank_facilities(specialties, capabilities, urgency)
        st.caption(f"Transfer window for {urgency}: {result['transfer_window_minutes']} minutes")

        for option in result["recommendations"]:
            with st.container(border=True):
                st.markdown(f"**{option['rank']}. {option['name']}** — score {option['score']:.2f}")
                for reason in option["reasons"]:
                    st.markdown(f"- {reason}")

        st.markdown("**Ruled out**")
        for item in result["excluded"]:
            st.markdown(f"- {item['name']}: {item['reason']}")
        st.caption("Showing why a facility was excluded is what stops a clinician overriding the ranking blindly.")

# ------------------------------------------------------------ assistant
with tab_assistant:
    st.markdown(
        "<div class='hg-demo'><b>Demonstration screen.</b> The refusal rules are real and run "
        "on every question. The answer text is a fixture; in production it is grounded in the "
        "patient's own record.</div>",
        unsafe_allow_html=True,
    )
    st.subheader("Patient and ASHA worker assistant")

    language = st.selectbox(
        "Language", sorted(LANGUAGES), index=sorted(LANGUAGES).index("hi"),
        format_func=lambda code: f"{LANGUAGES[code]} ({code})",
    )
    question = st.text_input("Question", "When is my next vaccination due?")

    if st.button("Ask"):
        reply = answer_question(question, language)
        if reply["escalated_to_human"]:
            st.error(reply["answer"])
            st.caption(reply["disclaimer"])
        else:
            st.success(reply["answer"])
            st.caption(reply["disclaimer"])

    with st.expander("What gets escalated instead of answered"):
        st.markdown(
            "Anything asking to start, stop or change a dose; anything asking for a diagnosis "
            "or a prognosis; anything asking for a prescription. These go to a clinician. "
            "A confident wrong answer about a dose is the specific harm this prevents."
        )

# -------------------------------------------------------------- imaging
with tab_imaging:
    st.markdown(
        "<div class='hg-demo'><b>Demonstration screen.</b> This returns a fixture, not a model "
        "call. The response shape matches what the production orchestrator returns, including "
        "the mandatory signature requirement.</div>",
        unsafe_allow_html=True,
    )
    st.subheader("Preliminary imaging read")

    uploaded = st.file_uploader("Chest radiograph", type=["jpg", "jpeg", "png"])
    if uploaded:
        st.image(uploaded, width=320, caption=uploaded.name)
        if st.button("Draft a preliminary read"):
            draft = draft_radiology_read(uploaded.name)
            st.markdown(f"**Modality** {draft['modality']} · **image quality** {draft['quality']}")
            for finding in draft["findings"]:
                st.markdown(f"- {finding['text']} — {finding['confidence']:.0%} confidence")
            st.markdown(f"**Impression** {draft['impression']}")
            st.error(
                "Preliminary. A qualified radiologist must review and sign this before it "
                "enters a patient record."
            )

st.divider()
st.caption(
    "HealthGrid AI · forecasts and stock figures are decision support, not a source of record. "
    "Verify against HMIS, DVDMS and the treating facility before acting."
)
