const pptxgen = require('pptxgenjs');
const pres = new pptxgen();
pres.layout = 'LAYOUT_WIDE';            // 13.33 x 7.5
pres.author = 'HealthGrid AI';
pres.title = 'HealthGrid AI - code review and regeneration';

// ---------- palette: National Health Mission green, saffron used only for action ----------
const GREEN = '046A38', GREEN_DEEP = '024524', NAVY = '0B3C5D';
const SAF = 'F47B20', SAF_WASH = 'FFF3E8';
const WASH = 'EEF5F1', WASH2 = 'F7FAF8', W = 'FFFFFF';
const INK = '1B2B34', MUT = '52616B', RULE = 'C9D9D0';
const HEAD = 'Cambria', BODY = 'Calibri';

const M = 0.6, CW = 13.33 - 2 * M;

function sh() { return { type: 'outer', color: 'A8BDB0', blur: 8, offset: 1, angle: 90, opacity: 0.3 }; }

function slide(dark) {
  const s = pres.addSlide();
  s.background = { color: dark ? NAVY : W };
  return s;
}

function title(s, kicker, text) {
  if (kicker) s.addText(kicker, {
    x: M, y: 0.34, w: CW, h: 0.28, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 11.5, bold: true, color: GREEN,
  });
  s.addText(text, {
    x: M, y: 0.6, w: CW, h: 0.62, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 30, bold: true, color: INK,
  });
}

function card(s, x, y, w, h, o) {
  o = o || {};
  s.addShape(pres.ShapeType.roundRect, {
    x, y, w, h, rectRadius: 0.06,
    fill: { color: o.fill || W },
    line: { color: o.line || RULE, width: o.lw || 1 },
    shadow: o.flat ? undefined : sh(),
  });
}

// The motif: nodes distributed on a ring -- a grid of facilities around a
// centre. Repeated on the opening and closing slides.
function ring(s, cx, cy, radius, nodes, color, dotSize) {
  s.addShape(pres.ShapeType.ellipse, {
    x: cx - radius, y: cy - radius, w: radius * 2, h: radius * 2,
    fill: { color: NAVY }, line: { color, width: 1 }, transparency: 100,
  });
  const d = dotSize || 0.11;
  for (let i = 0; i < nodes; i++) {
    const angle = (i / nodes) * Math.PI * 2 - Math.PI / 2;
    s.addShape(pres.ShapeType.ellipse, {
      x: cx + Math.cos(angle) * radius - d / 2,
      y: cy + Math.sin(angle) * radius - d / 2,
      w: d, h: d,
      fill: { color }, line: { color, width: 0.5 },
    });
  }
}

function iconCircle(s, x, y, d, glyph, fill, fg) {
  s.addShape(pres.ShapeType.ellipse, { x, y, w: d, h: d, fill: { color: fill }, line: { color: fill, width: 1 } });
  s.addText(glyph, {
    x, y, w: d, h: d, isTextBox: true, margin: 0, align: 'center', valign: 'middle',
    fontFace: BODY, fontSize: d > 0.5 ? 14 : 11, bold: true, color: fg || W,
  });
}

function footnote(s, text) {
  s.addText(text, {
    x: M, y: 7.0, w: CW, h: 0.28, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 9, italic: true, color: MUT,
  });
}

// =====================================================================
// 1 TITLE
// =====================================================================
(() => {
  const s = slide(true);
  ring(s, 11.0, 3.6, 1.95, 24, '4E93B5', 0.13);
  ring(s, 11.0, 3.6, 1.05, 12, SAF, 0.15);
  s.addShape(pres.ShapeType.ellipse, { x: 10.83, y: 3.43, w: 0.34, h: 0.34, fill: { color: SAF }, line: { color: SAF, width: 1 } });

  s.addText('HealthGrid AI', {
    x: M, y: 2.0, w: 8.6, h: 0.9, isTextBox: true, margin: 0,
    fontFace: HEAD, fontSize: 46, bold: true, color: W,
  });
  s.addText('Code review, compression and regeneration', {
    x: M, y: 2.95, w: 8.6, h: 0.5, isTextBox: true, margin: 0,
    fontFace: BODY, fontSize: 19, color: 'A9C9D8',
  });
  s.addText(
    'Disease burden forecasting and medicine procurement planning for India\u2019s public health network, ' +
    'rebuilt from the HMIS sub-district indicator extract.',
    { x: M, y: 3.6, w: 8.2, h: 0.8, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 13, color: '8FB3C4', lineSpacing: 19 },
  );

  const stats = [['400 MB', 'reviewed'], ['5', 'defects fixed'], ['1.6 MB', 'regenerated']];
  stats.forEach((st, i) => {
    const x = M + i * 2.75;
    s.addText(st[0], { x, y: 4.9, w: 2.5, h: 0.5, isTextBox: true, margin: 0, fontFace: HEAD, fontSize: 26, bold: true, color: SAF });
    s.addText(st[1], { x, y: 5.4, w: 2.5, h: 0.3, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 11.5, color: 'A9C9D8' });
  });

  s.addText('National Health Mission \u00b7 Ayushman Bharat Digital Mission alignment', {
    x: M, y: 6.6, w: 9, h: 0.3, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 10.5, color: '6E93A6',
  });
  s.addNotes('The review found five correctness defects. Two of them changed every number the dashboard displayed, so this is a correction deck as much as a status deck.');
})();

// =====================================================================
// 2 WHAT WAS REVIEWED
// =====================================================================
(() => {
  const s = slide();
  title(s, 'Starting point', 'What the archive contained');

  const left = [
    ['1,127', 'lines of Python across 12 files'],
    ['400 MB', 'extracted, 63 MB compressed'],
    ['286', 'health indicators, 36 states and union territories'],
    ['6', 'unused Google Cloud integration modules'],
  ];
  left.forEach((row, i) => {
    const y = 1.45 + i * 1.12;
    card(s, M, y, 6.1, 0.95, { fill: i % 2 ? WASH2 : WASH, flat: true });
    s.addText(row[0], { x: M + 0.25, y: y + 0.1, w: 1.8, h: 0.75, isTextBox: true, margin: 0, valign: 'middle', fontFace: HEAD, fontSize: 22, bold: true, color: GREEN });
    s.addText(row[1], { x: M + 2.1, y: y + 0.1, w: 3.85, h: 0.75, isTextBox: true, margin: 0, valign: 'middle', fontFace: BODY, fontSize: 12.5, color: INK, lineSpacing: 16 });
  });

  card(s, 7.1, 1.45, CW - 6.5, 4.4);
  s.addText('The verdict in one paragraph', {
    x: 7.45, y: 1.68, w: 5.2, h: 0.34, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 14, bold: true, color: NAVY,
  });
  s.addText(
    'The engineering shape is sound. Prophet for the time series, a disease-to-medicine dosage table to turn cases ' +
    'into procurement quantities, an agent planner that degrades to a heuristic rather than failing \u2014 these are ' +
    'the right choices.\n\n' +
    'What was wrong sat underneath them. The dataset\u2019s month field was misread, so every observation landed in ' +
    'January and Prophet trained on four points a year instead of forty-eight. State names were attached to codes ' +
    'by position rather than identity, so every label in the dashboard named the wrong state.\n\n' +
    'Neither defect throws an error. Both produce a screen that looks complete and is wrong.',
    { x: 7.45, y: 2.1, w: 5.2, h: 3.5, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 12, color: INK, lineSpacing: 17 },
  );

  card(s, M, 6.0, CW, 0.82, { fill: SAF_WASH, line: 'E8C49B', flat: true });
  s.addText([
    { text: 'Why it matters here:  ', options: { bold: true, color: '8A4B12' } },
    { text: 'these numbers are meant to drive medicine orders for a state. A projection that is silently wrong is worse than no projection, because a district officer will act on it.', options: { color: '6B4415' } },
  ], { x: M + 0.3, y: 6.12, w: CW - 0.6, h: 0.6, isTextBox: true, margin: 0, valign: 'middle', fontFace: BODY, fontSize: 12 });
})();

// =====================================================================
// 3 DEFECT 1 - DATES
// =====================================================================
(() => {
  const s = slide();
  title(s, 'Defect one', 'Every date collapsed into January');

  card(s, M, 1.45, 5.7, 2.35, { fill: WASH, flat: true });
  s.addText('What the source file does', { x: M + 0.28, y: 1.62, w: 5.1, h: 0.3, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 13, bold: true, color: NAVY });
  s.addText(
    'The HMIS extract encodes the month in the day position. 2018-01-04 is April 2018. ' +
    'Across the whole file the month component is always 01 and the day component runs 1 to 12.',
    { x: M + 0.28, y: 1.95, w: 5.15, h: 1.1, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 12, color: INK, lineSpacing: 17 },
  );
  s.addText('pd.to_datetime(df["date"])  \u2192  48 identical Januaries', {
    x: M + 0.28, y: 3.1, w: 5.15, h: 0.4, isTextBox: true, margin: 0,
    fontFace: 'Courier New', fontSize: 11, color: 'A8201A',
  });

  card(s, M, 3.98, 5.7, 1.9, { fill: WASH2, flat: true });
  s.addText('The correction', { x: M + 0.28, y: 4.14, w: 5.1, h: 0.3, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 13, bold: true, color: GREEN });
  s.addText(
    'd = pd.to_datetime(raw["date"])\nperiod = to_datetime(dict(\n    year=d.dt.year, month=d.dt.day, day=1))',
    { x: M + 0.28, y: 4.46, w: 5.15, h: 0.9, isTextBox: true, margin: 0, fontFace: 'Courier New', fontSize: 11, color: GREEN_DEEP, lineSpacing: 15 },
  );
  s.addText('Recovered range: January 2017 to May 2021, 923 populated state-months.', {
    x: M + 0.28, y: 5.4, w: 5.15, h: 0.3, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 11, italic: true, color: MUT,
  });

  card(s, 6.75, 1.45, CW - 6.15, 4.43);
  s.addText('BCG immunisations, Tamil Nadu \u2014 what the corrected series looks like', {
    x: 7.05, y: 1.62, w: 6.0, h: 0.34, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 12.5, bold: true, color: NAVY,
  });

  const hist = [['Aug 19', 81696], ['Oct 19', 91482], ['Dec 19', 77213], ['Feb 20', 100710],
    ['Apr 20', 141612], ['Jun 20', 160042], ['Aug 20', 152971], ['Oct 20', 171628],
    ['Dec 20', 157897], ['Apr 21', 112618], ['May 21', 126863]];
  const fore = [['Jul 21', 180478], ['Sep 21', 188656], ['Nov 21', 190030], ['Jan 22', 213268], ['Mar 22', 211529], ['May 22', 222659]];

  const axis = hist.map(h => h[0]).concat(fore.map(f => f[0]));
  s.addChart(
    pres.ChartType.line,
    [
      { name: 'Recorded', labels: axis, values: hist.map(h => h[1]).concat(fore.map(() => null)) },
      { name: 'Projected', labels: axis, values: hist.map(() => null).concat(fore.map(f => f[1])) },
    ],
    {
      x: 6.95, y: 2.05, w: 6.1, h: 3.6,
      chartColors: [GREEN, SAF],
      showLegend: true, legendPos: 'b', legendFontSize: 10, legendFontFace: BODY,
      lineDataSymbol: 'circle', lineDataSymbolSize: 5, lineSize: 2.5,
      catAxisLabelColor: MUT, valAxisLabelColor: MUT,
      catAxisLabelFontSize: 9, valAxisLabelFontSize: 9,
      catAxisLabelFontFace: BODY, valAxisLabelFontFace: BODY,
      valGridLine: { color: 'E4EDE8', size: 1 }, catGridLine: { style: 'none' },
      valAxisLabelFormatCode: '#,##0',
      dataLabelPosition: 'ctr', showValue: false,
    },
  );
  footnote(s, 'Recorded values from the HMIS extract; projection from the trend-and-seasonal baseline. The 2020 rise reflects a real reporting-coverage change, which a four-point-per-year series could never have shown.');
})();

// =====================================================================
// 4 DEFECT 2 - STATE NAMES
// =====================================================================
(() => {
  const s = slide();
  title(s, 'Defect two', 'State names were assigned by position, not identity');

  card(s, M, 1.45, 6.0, 2.0, { fill: SAF_WASH, line: 'E8C49B', flat: true });
  s.addText('What the code did', { x: M + 0.28, y: 1.62, w: 5.4, h: 0.3, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 13, bold: true, color: '8A4B12' });
  s.addText(
    'code_to_name = {code: STATES[i % len(STATES)]\n                for i, code in enumerate(codes)}',
    { x: M + 0.28, y: 1.95, w: 5.45, h: 0.7, isTextBox: true, margin: 0, fontFace: 'Courier New', fontSize: 10.5, color: '8A4B12', lineSpacing: 15 },
  );
  s.addText(
    'Modulo arithmetic over a sorted list of 77 codes against 36 hardcoded names. Every label was wrong, and two codes were shown as the same state.',
    { x: M + 0.28, y: 2.7, w: 5.45, h: 0.62, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 11.5, color: '6B4415', lineSpacing: 16 },
  );

  card(s, M, 3.65, 6.0, 1.55, { fill: WASH2, flat: true });
  s.addText('The correction', { x: M + 0.28, y: 3.8, w: 5.4, h: 0.3, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 13, bold: true, color: GREEN });
  s.addText(
    'The raw CSV carries state_name beside state_code on every row. The pipeline now uses it and the hardcoded list is gone.',
    { x: M + 0.28, y: 4.12, w: 5.45, h: 0.92, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 12, color: INK, lineSpacing: 17 },
  );

  card(s, 7.0, 1.45, CW - 6.4, 4.4);
  s.addText('Verified against census state codes', {
    x: 7.3, y: 1.65, w: 5.6, h: 0.32, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 12.5, bold: true, color: NAVY,
  });

  const rows = [
    [{ text: 'Code', options: { bold: true, color: NAVY } }, { text: 'Correct state', options: { bold: true, color: NAVY } }, { text: 'Shown before', options: { bold: true, color: NAVY } }],
    ['33', 'Tamil Nadu', 'Mizoram'],
    ['32', 'Kerala', 'Nagaland'],
    ['10', 'Bihar', 'Gujarat'],
    ['27', 'Maharashtra', 'Odisha'],
    ['09', 'Uttar Pradesh', 'Delhi'],
  ];
  s.addTable(rows, {
    x: 7.3, y: 2.08, w: 5.6, colW: [0.9, 2.4, 2.3],
    border: { type: 'solid', color: RULE, pt: 0.75 },
    fill: { color: W }, fontFace: BODY, fontSize: 11.5, color: INK,
    rowH: 0.42, valign: 'middle', margin: [3, 7, 3, 7],
  });
  s.addText(
    'The "shown before" column is what the modulo mapping produced for those codes. ' +
    'A district officer reading Tamil Nadu was looking at another state\u2019s disease burden.',
    { x: 7.3, y: 4.9, w: 5.6, h: 0.8, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 11, italic: true, color: MUT, lineSpacing: 15 },
  );
  footnote(s, 'A regression test now asserts Tamil Nadu is 33, Kerala 32 and Bihar 10, and that no two states share a code.');
})();

// =====================================================================
// 5 REMAINING DEFECTS
// =====================================================================
(() => {
  const s = slide();
  title(s, 'Defects three to five', 'Three more, each silent in its own way');

  const items = [
    ['\u21bb', 'Stock figures were redrawn on every request',
      'get_stockout_alerts called np.random.uniform per row to invent current stock, so the same query returned a different deficit each time. Streamlit\u2019s cache hid it by freezing whichever roll happened first.',
      'Now derived deterministically from a hash of the state and indicator: stable between refreshes, and replaced wholesale when a DVDMS feed connects.'],
    ['\u2260', 'A string reached isin(), which iterated its characters',
      'The API declared variable as a single string and passed it to a parameter typed as a list. isin("child_tb") matches the letters c, h, i, l, d \u2014 never the indicator. Every filtered query returned nothing and the endpoint answered 404.',
      'The engine now accepts either a single name or a list, and a test asserts both return the same twelve rows.'],
    ['\u21c4', 'Two sources of truth for the forecast',
      'train_prophet.py wrote a parquet file and its own docstring said not to use the Excel. The service read the Excel. The training output was never consumed by anything.',
      'One path now: a committed dataset, an optional trained-forecast file, and an engine that reports which of the two it is using.'],
  ];

  let y = 1.45;
  items.forEach((it, i) => {
    card(s, M, y, CW, 1.62, { fill: i % 2 ? WASH2 : WASH, flat: true });
    iconCircle(s, M + 0.3, y + 0.28, 0.54, it[0], i === 0 ? SAF : GREEN);
    s.addText(it[1], { x: M + 1.05, y: y + 0.18, w: 5.1, h: 0.62, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 13.5, bold: true, color: INK, lineSpacing: 17 });
    s.addText(it[2], { x: M + 1.05, y: y + 0.78, w: 5.1, h: 0.72, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 10.5, color: MUT, lineSpacing: 14 });
    s.addText(it[3], { x: M + 6.5, y: y + 0.24, w: CW - 6.9, h: 1.15, isTextBox: true, margin: 0, valign: 'middle', fontFace: BODY, fontSize: 11.5, color: GREEN_DEEP, lineSpacing: 16 });
    y += 1.72;
  });

  footnote(s, 'None of the five defects raised an exception. Each produced a plausible screen, which is why they survived to release.');
})();

// =====================================================================
// 6 COMPRESSION
// =====================================================================
(() => {
  const s = slide();
  title(s, 'Compression', '400 MB of storage served a state-level dashboard');

  card(s, M, 1.5, 5.5, 4.3);
  s.addText('What was actually needed', { x: M + 0.3, y: 1.72, w: 4.9, h: 0.32, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 13.5, bold: true, color: NAVY });
  s.addText(
    'The application only ever reads state-level monthly totals. The archive shipped sub-district ' +
    'granularity and five sector slices to serve a dashboard that aggregates all of it away on load.\n\n' +
    'Public plus Private re-sums to Total, and so does Rural plus Urban. Keeping all five would ' +
    'triple-count every case, so only Total survives the reduction.\n\n' +
    'Nothing was thrown away that the platform uses: all 286 indicators, all 36 states and union ' +
    'territories, every month from 2017 to 2021.',
    { x: M + 0.3, y: 2.12, w: 4.95, h: 3.2, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 12, color: INK, lineSpacing: 17 },
  );

  card(s, 6.4, 1.5, CW - 5.8, 4.3);
  s.addText('Extracted size, before and after', { x: 6.7, y: 1.72, w: 6.0, h: 0.32, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 13.5, bold: true, color: NAVY });

  s.addChart(
    pres.ChartType.bar,
    [{
      name: 'Megabytes',
      labels: ['Raw sub-district CSV', 'Prophet forecast workbook', 'Regenerated dataset'],
      values: [411.5, 7.2, 1.4],
    }],
    {
      x: 6.6, y: 2.15, w: 5.55, h: 2.5,
      barDir: 'bar', barGapWidthPct: 55,
      chartColors: [SAF, SAF, GREEN],
      varyColors: true,
      showLegend: false,
      showValue: true, dataLabelPosition: 'outEnd', dataLabelFontSize: 10,
      dataLabelFontFace: BODY, dataLabelColor: INK, dataLabelFormatCode: '#,##0.0" MB"',
      catAxisLabelColor: INK, catAxisLabelFontSize: 10, catAxisLabelFontFace: BODY,
      valAxisHidden: true, valGridLine: { style: 'none' }, catGridLine: { style: 'none' },
    },
  );

  const tiles = [['\u00f7 250', 'smaller on disk'], ['100%', 'indicators kept'], ['1 script', 'reproduces it']];
  tiles.forEach((t, i) => {
    const x = 6.7 + i * 2.05;
    s.addText(t[0], { x, y: 4.82, w: 1.95, h: 0.42, isTextBox: true, margin: 0, fontFace: HEAD, fontSize: 20, bold: true, color: GREEN });
    s.addText(t[1], { x, y: 5.24, w: 1.95, h: 0.3, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 10.5, color: MUT });
  });

  card(s, M, 6.0, CW, 0.8, { fill: WASH, flat: true });
  s.addText([
    { text: 'The reduction is committed as a script, not an artefact.  ', options: { bold: true, color: GREEN_DEEP } },
    { text: 'scripts/build_dataset.py runs in chunks against the raw extract, so the 1.4 MB file can always be rebuilt and audited rather than trusted.', options: { color: INK } },
  ], { x: M + 0.3, y: 6.12, w: CW - 0.6, h: 0.58, isTextBox: true, margin: 0, valign: 'middle', fontFace: BODY, fontSize: 12 });
})();

// =====================================================================
// 7 WHAT THE DATA HOLDS
// =====================================================================
(() => {
  const s = slide();
  title(s, 'The dataset', 'What the platform is reasoning over');

  const tiles = [
    ['263,978', 'observed state-months', GREEN],
    ['286', 'health indicators', NAVY],
    ['36', 'states and union territories', NAVY],
    ['14', 'disease programmes with a reviewed dosage', SAF],
  ];
  const tw = (CW - 3 * 0.3) / 4;
  tiles.forEach((t, i) => {
    const x = M + i * (tw + 0.3);
    card(s, x, 1.45, tw, 1.5, { fill: WASH2, flat: true });
    s.addText(t[0], { x: x + 0.22, y: 1.6, w: tw - 0.44, h: 0.6, isTextBox: true, margin: 0, fontFace: HEAD, fontSize: 26, bold: true, color: t[2] });
    s.addText(t[1], { x: x + 0.22, y: 2.2, w: tw - 0.44, h: 0.6, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 11.5, color: MUT, lineSpacing: 15 });
  });

  card(s, M, 3.2, 6.3, 2.75);
  s.addText('From cases to a purchase order', { x: M + 0.3, y: 3.4, w: 5.7, h: 0.32, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 13.5, bold: true, color: NAVY });

  const steps = [
    'Project the next twelve months per state and indicator',
    'Multiply by the reviewed per-case dosage',
    'Add a 30% safety buffer',
    'Compare against stock on hand',
    'Rank the shortfall into order now, this quarter, or monitor',
  ];
  steps.forEach((step, i) => {
    const y = 3.82 + i * 0.4;
    iconCircle(s, M + 0.32, y, 0.26, String(i + 1), i === 3 ? SAF : GREEN);
    s.addText(step, { x: M + 0.72, y: y - 0.04, w: 5.3, h: 0.34, isTextBox: true, margin: 0, valign: 'middle', fontFace: BODY, fontSize: 11.5, color: INK });
  });

  card(s, 7.2, 3.2, CW - 6.6, 2.75);
  s.addText('Tamil Nadu, the four largest shortfalls', { x: 7.5, y: 3.4, w: 5.4, h: 0.32, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 13.5, bold: true, color: NAVY });

  const alerts = [
    [{ text: 'Medicine', options: { bold: true, color: NAVY } }, { text: 'Shortfall', options: { bold: true, color: NAVY } }, { text: 'Priority', options: { bold: true, color: NAVY } }],
    ['Iron and folic acid, postpartum', '370.8 m tablets', 'Order now'],
    ['Iron and folic acid, pregnancy', '359.1 m tablets', 'Order now'],
    ['BCG vaccine', '1.24 m doses', 'Order now'],
    ['Ringer lactate and ORS', '0.77 m units', 'Order now'],
  ];
  s.addTable(alerts, {
    x: 7.45, y: 3.82, w: 5.05, colW: [2.5, 1.4, 1.15],
    border: { type: 'solid', color: RULE, pt: 0.75 },
    fill: { color: W }, fontFace: BODY, fontSize: 10.5, color: INK,
    rowH: 0.36, valign: 'middle', margin: [2, 6, 2, 6],
  });

  footnote(s, 'Shortfall figures derive from an estimated stock position. They are stable and reproducible, but they are not a warehouse reading \u2014 see the following slide.');
})();

// =====================================================================
// 8 REAL VS ESTIMATED VS FIXTURE
// =====================================================================
(() => {
  const s = slide();
  title(s, 'Honesty about the numbers', 'What is real, what is estimated, what is a fixture');

  const rows = [
    [{ text: 'Shown on screen', options: { bold: true } }, { text: 'Status', options: { bold: true } }, { text: 'What it rests on', options: { bold: true } }],
    ['Observed monthly cases', 'Real', 'HMIS sub-district extract, aggregated to state and month'],
    ['Twelve-month projection', 'Real', 'Trend and seasonal baseline, or Prophet when trained. The method is stated in the interface'],
    ['Per-case medicine dosage', 'Real', '14 disease programmes aligned to standard treatment guidelines'],
    ['Required quantity', 'Derived', 'Projected cases \u00d7 dosage + 30% buffer'],
    ['Stock on hand', 'Estimated', 'Deterministic placeholder. Needs a DVDMS or e-Aushadhi feed'],
    ['Shortfall and priority tier', 'Estimated', 'Follows directly from the stock estimate above'],
    ['Referral ranking weights', 'Real', 'Clinical fit 40, travel 25, load 20, continuity 10, cost 5'],
    ['Referral facilities and beds', 'Fixture', 'No facility registry connected in this prototype'],
    ['Assistant refusal rules', 'Real', 'Dose, diagnosis and prognosis questions always escalate'],
    ['Assistant answer text', 'Fixture', 'Production grounds answers in the patient\u2019s own record'],
    ['Imaging findings', 'Fixture', 'Not a model call. Always requires a radiologist signature'],
  ];

  s.addTable(rows, {
    x: M, y: 1.45, w: CW, colW: [3.4, 1.5, 7.23],
    border: { type: 'solid', color: RULE, pt: 0.75 },
    fill: { color: W }, fontFace: BODY, fontSize: 10.5, color: INK,
    rowH: 0.375, valign: 'middle', margin: [2, 7, 2, 7],
  });

  card(s, M, 6.35, CW, 0.62, { fill: SAF_WASH, line: 'E8C49B', flat: true });
  s.addText([
    { text: 'The row that matters:  ', options: { bold: true, color: '8A4B12' } },
    { text: 'no purchase order should be raised against an estimated stock position. Every fixture screen in the dashboard says so on the screen itself, not in a footnote.', options: { color: '6B4415' } },
  ], { x: M + 0.3, y: 6.42, w: CW - 0.6, h: 0.48, isTextBox: true, margin: 0, valign: 'middle', fontFace: BODY, fontSize: 11.5 });
})();

// =====================================================================
// 9 REGENERATED STRUCTURE
// =====================================================================
(() => {
  const s = slide();
  title(s, 'Regenerated', 'Twelve files, one path through the data');

  const lanes = [
    ['Data', GREEN, [
      ['scripts/build_dataset.py', '411 MB raw extract \u2192 1.4 MB committed dataset, with the month reconstruction'],
      ['scripts/train_prophet.py', 'Optional Prophet fit per state and indicator, writes the forecast file'],
      ['data/state_monthly_indicators.csv.gz', '263,978 observations, documented provenance'],
    ]],
    ['Engine', NAVY, [
      ['backend/forecasting.py', 'History, projection, medicine demand, shortfall ranking'],
      ['backend/procurement.py', 'Vertex AI agent crew, falling back to a deterministic planner'],
      ['backend/clinical.py', 'Referral, assistant, imaging. Real refusal rules, fixture content'],
    ]],
    ['Surface', SAF, [
      ['backend/main.py', 'FastAPI. Restricted CORS, health endpoint reports what is loaded'],
      ['frontend/app.py', 'Streamlit dashboard, six tabs, provenance stated on every number'],
      ['tests/test_forecasting.py', 'One test per defect fixed, each naming what it guards'],
    ]],
  ];

  const lw = (CW - 2 * 0.3) / 3;
  lanes.forEach((lane, i) => {
    const x = M + i * (lw + 0.3);
    card(s, x, 1.45, lw, 4.5, { fill: WASH2, flat: true });
    s.addShape(pres.ShapeType.roundRect, { x: x + 0.01, y: 1.46, w: lw - 0.02, h: 0.52, rectRadius: 0.06, fill: { color: lane[1] }, line: { color: lane[1], width: 1 } });
    s.addText(lane[0], { x: x + 0.25, y: 1.46, w: lw - 0.5, h: 0.52, isTextBox: true, margin: 0, valign: 'middle', fontFace: BODY, fontSize: 14, bold: true, color: W });

    lane[2].forEach((entry, j) => {
      const y = 2.15 + j * 1.28;
      s.addText(entry[0], { x: x + 0.25, y, w: lw - 0.5, h: 0.4, isTextBox: true, margin: 0, fontFace: 'Courier New', fontSize: 9.5, bold: true, color: lane[1], lineSpacing: 12 });
      s.addText(entry[1], { x: x + 0.25, y: y + 0.42, w: lw - 0.5, h: 0.8, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 10.5, color: MUT, lineSpacing: 14 });
    });
  });

  card(s, M, 6.1, CW, 0.75, { fill: WASH, flat: true });
  s.addText(
    'backend/common/ also carries the Google Cloud integration \u2014 FHIR reads behind a consent gate, ABDM consent artefacts, ' +
    'Vertex AI with schema-validated output. It is kept because that is where the clinical endpoints go when they stop being ' +
    'fixtures, not because the unified server uses it today.',
    { x: M + 0.3, y: 6.2, w: CW - 0.6, h: 0.58, isTextBox: true, margin: 0, valign: 'middle', fontFace: BODY, fontSize: 11.5, color: INK, lineSpacing: 15 },
  );
})();

// =====================================================================
// 10 INDIAN SYSTEM INTEGRATION
// =====================================================================
(() => {
  const s = slide();
  title(s, 'National systems', 'Where this plugs into India\u2019s health stack');

  const systems = [
    ['HMIS', 'Health Management Information System', 'Source of the indicator extract. Currently a static file to May 2021; needs the live feed for the projection to describe today.', 'Connected, static'],
    ['DVDMS', 'Drug and Vaccine Distribution Management System', 'Actual stock on hand per warehouse. This is the single missing input that turns estimated shortfalls into real ones.', 'Required next'],
    ['e-Aushadhi', 'State drug logistics platform', 'State-level alternative to DVDMS for stock and indent raising. One of the two is enough.', 'Alternative'],
    ['ABDM and ABHA', 'Ayushman Bharat Digital Mission', 'Patient identity and consent artefacts for the clinical surfaces. Sandbox certification is the long lead item.', 'For clinical tabs'],
    ['HFR and HPR', 'Facility and professional registries', 'Facility capability and bed data for the referral engine; clinician identity for sign-off.', 'For referral'],
    ['IHIP and IDSP', 'Integrated disease surveillance', 'Outbreak signals to validate the projection against reported field events.', 'For validation'],
  ];

  const cw2 = (CW - 2 * 0.28) / 3;
  systems.forEach((sys, i) => {
    const col = i % 3, row = Math.floor(i / 3);
    const x = M + col * (cw2 + 0.28), y = 1.45 + row * 2.42;
    const urgent = sys[3] === 'Required next';
    card(s, x, y, cw2, 2.2, { fill: urgent ? SAF_WASH : WASH2, line: urgent ? 'E8C49B' : RULE, flat: true });
    s.addText(sys[0], { x: x + 0.24, y: y + 0.18, w: cw2 - 0.48, h: 0.34, isTextBox: true, margin: 0, fontFace: HEAD, fontSize: 17, bold: true, color: urgent ? '8A4B12' : NAVY });
    s.addText(sys[1], { x: x + 0.24, y: y + 0.52, w: cw2 - 0.48, h: 0.42, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 10, color: MUT, lineSpacing: 13 });
    s.addText(sys[2], { x: x + 0.24, y: y + 0.98, w: cw2 - 0.48, h: 0.86, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 11, color: INK, lineSpacing: 15 });
    s.addText(sys[3], { x: x + 0.24, y: y + 1.85, w: cw2 - 0.48, h: 0.28, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 10, bold: true, color: urgent ? SAF : GREEN });
  });

  footnote(s, 'Deployment region asia-south1 (Mumbai) with asia-south2 (Delhi) for disaster recovery; no clinical data leaves India.');
})();

// =====================================================================
// 11 TESTS
// =====================================================================
(() => {
  const s = slide();
  title(s, 'Regression cover', 'A test for every defect, naming what it guards');

  const tests = [
    ['test_dates_span_all_twelve_months', 'Fails with "all observations collapsed into one month" if the date reconstruction breaks again.'],
    ['test_state_names_match_their_census_codes', 'Asserts Tamil Nadu is 33, Kerala 32, Bihar 10, and that no two states share a code.'],
    ['test_stockout_alerts_are_reproducible', 'Calls twice and compares every deficit, so a random draw cannot return unnoticed.'],
    ['test_single_variable_filter_returns_rows', 'Passes both a string and a list, and requires the same twelve rows from each.'],
    ['test_every_curated_indicator_exists_in_the_data', 'Catches a mapped medicine whose indicator is not in the file \u2014 the silent failure that dropped four disease programmes.'],
    ['test_forecasts_are_never_negative', 'A negative case count is a fitting artefact, not a forecast.'],
    ['test_alerts_declare_their_provenance', 'Every alert must state its forecast method and that stock is estimated.'],
    ['test_unsafe_questions_are_escalated', 'Five phrasings of dose and diagnosis questions must all route to a human.'],
  ];

  card(s, M, 1.45, CW, 4.85, { flat: true });
  tests.forEach((t, i) => {
    const y = 1.6 + i * 0.58;
    if (i % 2 === 0) {
      s.addShape(pres.ShapeType.rect, { x: M + 0.08, y: y - 0.06, w: CW - 0.16, h: 0.54, fill: { color: WASH2 }, line: { color: WASH2, width: 0.5 } });
    }
    iconCircle(s, M + 0.24, y + 0.06, 0.3, '\u2713', GREEN);
    s.addText(t[0], { x: M + 0.68, y: y + 0.02, w: 4.5, h: 0.38, isTextBox: true, margin: 0, valign: 'middle', fontFace: 'Courier New', fontSize: 10, bold: true, color: NAVY });
    s.addText(t[1], { x: M + 5.3, y: y, w: CW - 5.6, h: 0.44, isTextBox: true, margin: 0, valign: 'middle', fontFace: BODY, fontSize: 11, color: INK, lineSpacing: 14 });
  });

  card(s, M, 6.45, CW, 0.6, { fill: WASH, flat: true });
  s.addText(
    'Ten test bodies were executed against the regenerated dataset and all pass. pytest itself could not be installed in the ' +
    'build environment, so the assertions were run directly \u2014 run pytest tests -q once on your machine to confirm.',
    { x: M + 0.3, y: 6.52, w: CW - 0.6, h: 0.46, isTextBox: true, margin: 0, valign: 'middle', fontFace: BODY, fontSize: 11, italic: true, color: MUT },
  );
})();

// =====================================================================
// 12 CLOSE
// =====================================================================
(() => {
  const s = slide(true);
  ring(s, 13.05, 7.25, 1.25, 20, '3C7C9E', 0.11);

  s.addText('Before this informs a real procurement decision', {
    x: M, y: 0.9, w: 10.5, h: 0.6, isTextBox: true, margin: 0, fontFace: HEAD, fontSize: 30, bold: true, color: W,
  });

  const actions = [
    ['Connect DVDMS or e-Aushadhi', 'The only remaining input that turns an estimated shortfall into a real one. Everything else on the supply tab is already derived from real data.'],
    ['Have a physician review the dosages', 'Fourteen per-case quantities drive every order figure. They are plausible against standard treatment guidelines; they are not yet signed off by a public health physician.'],
    ['Extend the extract past May 2021', 'A projection from four-year-old data describes 2021. The method is sound; the input is stale.'],
    ['Validate on a district the team knows', 'Compare the projection against a block whose burden the team can recall, before trusting it for one they cannot.'],
  ];

  actions.forEach((a, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = M + col * 5.6, y = 1.85 + row * 1.9;
    s.addShape(pres.ShapeType.roundRect, { x, y, w: 5.3, h: 1.65, rectRadius: 0.06, fill: { color: '15506F' }, line: { color: '2F6F8F', width: 1 } });
    iconCircle(s, x + 0.25, y + 0.24, 0.34, String(i + 1), SAF);
    s.addText(a[0], { x: x + 0.7, y: y + 0.2, w: 4.4, h: 0.4, isTextBox: true, margin: 0, valign: 'middle', fontFace: BODY, fontSize: 13, bold: true, color: W });
    s.addText(a[1], { x: x + 0.25, y: y + 0.66, w: 4.85, h: 0.9, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 10.5, color: 'A9C9D8', lineSpacing: 14 });
  });

  s.addText(
    'The code is decision support, not a source of record. Verify against HMIS, DVDMS and the treating facility before acting.',
    { x: M, y: 5.9, w: 9.5, h: 0.5, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 12.5, italic: true, color: '8FB3C4', lineSpacing: 17 },
  );
  s.addText('HealthGrid AI \u00b7 asia-south1 \u00b7 review and regeneration, version 3.0.0', {
    x: M, y: 6.75, w: 9.5, h: 0.3, isTextBox: true, margin: 0, fontFace: BODY, fontSize: 10, color: '6E93A6',
  });
  s.addNotes('Close on the one blocking dependency: stock data. Everything else is either already real or a known, labelled gap.');
})();

pres.writeFile({ fileName: '/home/claude/HealthGrid_AI_Review_Regeneration.pptx' })
  .then(f => console.log('WROTE ' + f));
