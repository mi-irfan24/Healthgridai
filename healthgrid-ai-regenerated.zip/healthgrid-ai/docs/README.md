# docs

## `deck_generator.js`

Builds `HealthGrid_AI_Review_Regeneration.pptx` — the twelve-slide review deck
covering the defects found, the compression, and the regenerated structure.

```bash
node docs/deck_generator.js
```

Requires `pptxgenjs`. The BCG chart and the Tamil Nadu shortfall table are real
engine output, not illustrative figures: if the data or the engine changes, the
numbers in the script need regenerating from
`engine.get_history()` and `engine.get_stockout_alerts()` rather than editing by
hand.
