#!/usr/bin/env python3
"""Reduce the raw sub-district indicator CSV to the compact file the app reads.

The source file is 411 MB and the platform only ever uses state-level monthly
totals, so shipping it is 400 MB of storage to serve data the dashboard
aggregates away on load. This script does that aggregation once, in chunks, and
writes a 1.4 MB gzipped long-format file.

Two corrections happen here, both documented in ANALYSIS.md:

  1. The source encodes the month in the day position -- 2018-01-04 is April
     2018. Parsing it directly collapses every record to January.
  2. State names come from the CSV's own state_name column, not from a
     positional lookup.

Run:
    python scripts/build_dataset.py --source path/to/major-health-indicators-subdistrict-level.csv

Output:
    data/state_monthly_indicators.csv.gz
      date, state_code, state_name, variable, value
"""
from __future__ import annotations

import argparse
import logging
import os
import sys

import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
log = logging.getLogger("build_dataset")

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_OUT = os.path.join(REPO, "data", "state_monthly_indicators.csv.gz")

# Identifier columns. Everything else numeric is a health indicator.
META = {
    "id", "date", "state_name", "state_code", "district_name", "district_code",
    "subdistrict_name", "subdistrict_code", "sector",
}


def build(source: str, out_path: str, chunk_size: int = 100_000) -> pd.DataFrame:
    if not os.path.exists(source):
        raise SystemExit(f"Source not found: {source}")

    log.info("Reading %s in %s-row chunks", source, f"{chunk_size:,}")
    parts: list[pd.DataFrame] = []
    indicators: list[str] | None = None

    for index, chunk in enumerate(pd.read_csv(source, chunksize=chunk_size, low_memory=False)):
        # Keep only the Total sector. Public + Private and Rural + Urban each
        # re-sum to Total, so including them would triple-count every case.
        chunk = chunk[chunk["sector"].astype(str).str.strip().str.lower() == "total"]
        if chunk.empty:
            continue

        if indicators is None:
            indicators = [
                c for c in chunk.columns
                if c not in META and pd.api.types.is_numeric_dtype(chunk[c])
            ]
            log.info("Found %d health indicator columns", len(indicators))

        raw = pd.to_datetime(chunk["date"], errors="coerce")
        period = pd.to_datetime(
            dict(year=raw.dt.year, month=raw.dt.day, day=1), errors="coerce"
        )
        chunk = chunk.assign(period=period).dropna(subset=["period"])

        parts.append(
            chunk.groupby(["period", "state_code", "state_name"], as_index=False)[indicators]
            .sum(min_count=1)
        )
        log.info("  chunk %d aggregated", index + 1)

    if not parts:
        raise SystemExit("No rows survived the sector=Total filter. Check the source file.")

    wide = pd.concat(parts, ignore_index=True)
    wide = wide.groupby(["period", "state_code", "state_name"], as_index=False)[indicators].sum(min_count=1)
    log.info("State-month rows: %d", len(wide))

    long = (
        wide.melt(
            id_vars=["period", "state_code", "state_name"],
            var_name="variable",
            value_name="value",
        )
        .dropna(subset=["value"])
        .rename(columns={"period": "date"})
    )
    long["value"] = long["value"].astype("int64")
    long = long.sort_values(["state_name", "variable", "date"])

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    long.to_csv(out_path, index=False, compression={"method": "gzip", "compresslevel": 9})

    size_mb = os.path.getsize(out_path) / 1e6
    log.info(
        "Wrote %s (%.2f MB): %s rows, %d states, %d indicators, %s to %s",
        out_path, size_mb, f"{len(long):,}",
        long["state_name"].nunique(), long["variable"].nunique(),
        long["date"].min().date(), long["date"].max().date(),
    )
    return long


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, help="Path to the raw sub-district CSV")
    parser.add_argument("--out", default=DEFAULT_OUT)
    parser.add_argument("--chunk-size", type=int, default=100_000)
    args = parser.parse_args()

    build(args.source, args.out, args.chunk_size)
    return 0


if __name__ == "__main__":
    sys.exit(main())
