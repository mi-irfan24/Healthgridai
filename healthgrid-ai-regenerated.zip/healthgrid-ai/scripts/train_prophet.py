#!/usr/bin/env python3
"""Train Prophet per (state, indicator) and write forecasts the app will use.

Run after scripts/build_dataset.py:

    python scripts/train_prophet.py                 # curated indicators only
    python scripts/train_prophet.py --all           # all 286
    python scripts/train_prophet.py --state "Tamil Nadu"

Output: data/prophet_forecasts.csv.gz. The engine picks it up automatically on
next start and reports method="prophet" instead of "baseline".

The uploaded version fed Prophet dates parsed straight from the source, where
the month sits in the day position, so every observation landed in January and
each series was four points instead of forty-eight. That is fixed upstream in
build_dataset.py; this script reads the corrected file.
"""
from __future__ import annotations

import argparse
import logging
import multiprocessing
import os
import sys
import warnings

import pandas as pd

warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
log = logging.getLogger("train_prophet")

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IN_PATH = os.path.join(REPO, "data", "state_monthly_indicators.csv.gz")
OUT_PATH = os.path.join(REPO, "data", "prophet_forecasts.csv.gz")

FORECAST_MONTHS = 12
MIN_OBSERVATIONS = 12  # Prophet on fewer monthly points is not worth trusting


def _fit_one(state_code, state_name, variable, frame, months):
    from prophet import Prophet

    history = frame.rename(columns={"date": "ds", "value": "y"})[["ds", "y"]]
    if len(history) < MIN_OBSERVATIONS:
        return None

    model = Prophet(
        yearly_seasonality=True,
        weekly_seasonality=False,
        daily_seasonality=False,
        # Public health series shift level when a programme changes; a flexible
        # trend tracks that better than the default.
        changepoint_prior_scale=0.1,
        interval_width=0.80,
    )
    model.fit(history)

    future = model.make_future_dataframe(periods=months, freq="MS")
    predicted = model.predict(future).tail(months)

    return pd.DataFrame({
        "date": predicted["ds"].values,
        "state_code": state_code,
        "state_name": state_name,
        "variable": variable,
        "forecast": predicted["yhat"].clip(lower=0).round(2).values,
        "forecast_lower": predicted["yhat_lower"].clip(lower=0).round(2).values,
        "forecast_upper": predicted["yhat_upper"].clip(lower=0).round(2).values,
    })


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default=IN_PATH)
    parser.add_argument("--out", default=OUT_PATH)
    parser.add_argument("--state", default=None, help="Limit to one state")
    parser.add_argument("--all", action="store_true", help="All indicators, not just curated")
    parser.add_argument("--months", type=int, default=FORECAST_MONTHS)
    parser.add_argument("--jobs", type=int, default=max(1, multiprocessing.cpu_count() - 1))
    args = parser.parse_args()

    try:
        from joblib import Parallel, delayed
        import prophet  # noqa: F401
    except ImportError:
        log.error(
            "prophet and joblib are required. pip install prophet joblib, "
            "then re-run. Until then the engine uses its baseline forecast."
        )
        return 1

    if not os.path.exists(args.input):
        log.error("Input missing: %s. Run scripts/build_dataset.py first.", args.input)
        return 1

    data = pd.read_csv(args.input, parse_dates=["date"])
    log.info("Loaded %s observations", f"{len(data):,}")

    if args.state:
        data = data[data["state_name"].str.lower() == args.state.strip().lower()]
        log.info("Filtered to %s: %s rows", args.state, f"{len(data):,}")

    if not args.all:
        sys.path.insert(0, REPO)
        from backend.forecasting import DISEASE_MEDICINE_MAPPING

        data = data[data["variable"].isin(DISEASE_MEDICINE_MAPPING)]
        log.info(
            "Curated indicators only: %s rows across %d indicators. Pass --all for every indicator.",
            f"{len(data):,}", data["variable"].nunique(),
        )

    groups = list(data.groupby(["state_code", "state_name", "variable"], sort=False))
    log.info("Fitting %d series on %d worker(s)", len(groups), args.jobs)

    results = Parallel(n_jobs=args.jobs, verbose=5)(
        delayed(_fit_one)(code, name, variable, frame, args.months)
        for (code, name, variable), frame in groups
    )

    frames = [frame for frame in results if frame is not None]
    if not frames:
        log.error("No series had at least %d monthly observations.", MIN_OBSERVATIONS)
        return 1

    output = pd.concat(frames, ignore_index=True)
    output.to_csv(args.out, index=False, compression={"method": "gzip", "compresslevel": 9})

    log.info(
        "Wrote %s (%.2f MB): %s forecast points from %d series",
        args.out, os.path.getsize(args.out) / 1e6, f"{len(output):,}", len(frames),
    )
    log.info("Skipped %d series with too little history.", len(results) - len(frames))
    return 0


if __name__ == "__main__":
    sys.exit(main())
