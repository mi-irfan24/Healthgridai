# Code review: healthgrid-ai-unified

Reviewed the uploaded archive (63 MB compressed, 400 MB extracted, 1,127 lines of
Python across 12 files) before regenerating it. Findings are ordered by how much
they would hurt if the platform went live as-is.

## Correctness

### 1. Every date in the dataset collapses to January

The source CSV encodes the **month in the day position**. `2018-01-04` is April
2018, not 4 January 2018. Sampling confirms it: across the whole file the month
component is always `01` and the day component ranges 1–12.

`train_prophet.py` does `pd.to_datetime(df["date"])` and then trains Prophet on
the result. So Prophet received four identical January timestamps per year
instead of 48 monthly observations. Any seasonality it found was an artefact,
and the trend was fitted through four points rather than forty-eight.

This is the single most consequential defect in the archive. Everything
downstream — forecasts, stockout deficits, procurement priorities — inherits it.

Fixed by reconstructing the period as `year` + `day-as-month`:

```python
d = pd.to_datetime(ch["date"], errors="coerce")
period = pd.to_datetime(dict(year=d.dt.year, month=d.dt.day, day=1))
```

Corrected range: January 2017 to May 2021, 923 populated state-months.

### 2. State names were assigned by position, not by identity

`forecasting_service._load_data` mapped the Excel's 77 `state_code` values onto
a hardcoded list of 36 state names with:

```python
code_to_name = {code: INDIAN_STATES_NAMES[i % len(INDIAN_STATES_NAMES)]
                for i, code in enumerate(unique_codes)}
```

Modulo arithmetic over a sorted code list. Every name in the dashboard was
wrong, and two different codes were labelled the same state. A district officer
reading "Tamil Nadu" was shown another state's burden.

The raw CSV carries `state_name` next to `state_code` already. The regenerated
pipeline uses it and drops the hardcoded list entirely.

### 3. Stockout alerts change on every page refresh

`get_stockout_alerts` calls `np.random.uniform(0.4, 0.95)` per row to invent
current stock. Two consequences: the same query returns different deficits each
time, and `st.cache_data` in the frontend hides that by freezing whichever roll
happened first.

An officer cannot act on a number that moves when she reloads. Regenerated with
a deterministic per-item value seeded from the state and variable, so it is
stable and reproducible — and labelled as an estimate everywhere it appears,
with the DVDMS integration point named.

### 4. `get_state_forecasts` signature mismatch

`main.py` declares `variable: Optional[str]` and passes a bare string to a
parameter typed `Optional[List[str]]`, which then reaches
`filtered["variable"].isin(variable)`. `isin` on a string iterates characters,
so `?variable=child_tb` matches nothing and returns an empty list. The endpoint
404s on a valid variable.

### 5. Two sources of truth for forecasts

`train_prophet.py` writes `State_Prophet_Forecasts_clean.parquet` and its own
docstring says not to use the Excel file. `forecasting_service.py` reads the
Excel file. The pipeline output was never consumed.

## Size

| Item | Before | After |
|---|---|---|
| `major-health-indicators-subdistrict-level.csv` | 411 MB | removed |
| `State_Prophet_Forecasts.xlsx` | 7.2 MB | removed |
| `state_monthly_indicators.csv.gz` | — | 1.4 MB |
| `__pycache__` (cpython-314) | 4 files | removed |
| **Extracted total** | **400 MB** | **~1.6 MB** |

The 411 MB was never needed at runtime. The app only ever reads state-level
monthly totals, so the archive shipped sub-district granularity and four
redundant sector slices (`Public` + `Private` and `Rural` + `Urban` both re-sum
to `Total`) to serve a dashboard that aggregates all of it away on load.

`scripts/build_dataset.py` performs the reduction in chunks and is committed, so
the compact file is reproducible from the source rather than being an opaque
artefact. 286 indicators, 36 states and union territories, all preserved.

## Structure

- `backend/services/common/` — six modules for FHIR, ABDM, Vertex AI, config and
  observability. Nothing in `main.py` imports them. They are the real GCP
  integration path, so they are kept and re-homed at `backend/common/`, but the
  unified server does not yet use them and the README now says so rather than
  implying otherwise.
- `requirements.txt` — `google-cloud-vertexai` is not a package on PyPI
  (`google-cloud-aiplatform` is), so a clean `pip install -r requirements.txt`
  fails. Nothing is pinned, and `crewai` pulls a large transitive tree that
  conflicts with `langchain-google-vertexai` versions in practice.
- `Dockerfile` — exposes 8501 and 8000 but the `CMD` starts only Streamlit. The
  FastAPI service in `main.py` never runs in the container, and the frontend
  imports the engine in-process, so the API is dead code at runtime.
- Duplicated logic — the safety-refusal keyword list and the referral fixtures
  exist separately in `main.py` and `frontend/app.py` and had already diverged
  (`"will i die"` in one, absent from the other).

## Claims that overstate what the code does

Worth correcting before this is shown to a health department:

- The frontend reports "🟢 Vertex AI Gemini 2.5: Configured" and "🟢 GCP
  Healthcare API: Online" as hardcoded strings. Nothing is checked.
- Tab 2 says "Runs 5 Vertex AI Gemini agents". The code defines three.
- Tab 5's radiology output is a hardcoded JSON literal, not a model call.
- Tabs 3, 4 and 5 are fixtures. The regenerated UI labels them as
  demonstrations, because a committee shown a live-looking screen will assume it
  is live.

## What was already sound

The disease-to-medicine mapping with per-case dosages is the most useful thing
in the archive: it is what turns a case forecast into a procurement quantity,
the dosages are plausible against Indian standard treatment guidelines, and it
is kept unchanged. The CrewAI fallback path is also correct in shape — it
degrades to a heuristic plan instead of failing the request. The Streamlit
caching decorators are applied in the right places.
